const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

// إعداد قاعدة البيانات
let db;
if (process.env.DATABASE_URL) {
    // استخدام PostgreSQL على Heroku
    const { Pool } = require('pg');
    db = new Pool({
        connectionString: process.env.DATABASE_URL,
        ssl: {
            rejectUnauthorized: false
        }
    });
    console.log('🔗 متصل بـ PostgreSQL (Heroku)');
} else {
    // استخدام SQLite محلياً
    const Database = require('better-sqlite3');
    db = new Database('classroom_system.db');
    console.log('💾 متصل بـ SQLite (محلياً)');
}

const multer = require('multer');
const xlsx = require('xlsx');
const QRCode = require('qrcode');
const dayjs = require('dayjs');

const app = express();
const PORT = process.env.PORT || 3000;

// إعداد المتغيرات الأساسية
app.use(cors({
    origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : '*',
    credentials: true
}));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// إضافة headers أمنية
app.use((req, res, next) => {
    res.header('X-Content-Type-Options', 'nosniff');
    res.header('X-Frame-Options', 'DENY');
    res.header('X-XSS-Protection', '1; mode=block');
    next();
});

// Rate limiting بسيط
const rateLimiter = new Map();

/**
 * Rate Limiting بسيط
 */
function simpleRateLimiter(req, res, next) {
    const ip = req.ip || req.connection.remoteAddress;
    const now = Date.now();
    const windowMs = 15 * 60 * 1000; // 15 دقيقة
    const maxRequests = 100; // 100 طلب لكل 15 دقيقة

    if (!rateLimiter.has(ip)) {
        rateLimiter.set(ip, { count: 1, resetTime: now + windowMs });
        return next();
    }

    const limiter = rateLimiter.get(ip);
    
    if (now > limiter.resetTime) {
        limiter.count = 1;
        limiter.resetTime = now + windowMs;
        return next();
    }

    if (limiter.count >= maxRequests) {
        return res.status(429).json({ 
            error: 'تم تجاوز الحد الأقصى للطلبات، يرجى المحاولة لاحقاً',
            resetTime: new Date(limiter.resetTime).toISOString()
        });
    }

    limiter.count++;
    next();
}

// تطبيق Rate Limiting على جميع APIs
app.use('/api/', rateLimiter);

// إعداد JWT
const JWT_SECRET = process.env.JWT_SECRET || 'classroom-secret-key-2024';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

// ================================
// Middleware للمصادقة والأمان
// ================================

/**
 * إنشاء token للمصادقة
 * @param {Object} payload - بيانات المستخدم
 * @returns {String} JWT token
 */
function createToken(payload) {
    return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
}

/**
 * التحقق من صحة JWT token
 * @param {String} token - JWT token
 * @returns {Object|null} payload مفكوك أو null
 */
function verifyToken(token) {
    try {
        return jwt.verify(token, JWT_SECRET);
    } catch (error) {
        return null;
    }
}

/**
 * Middleware للمصادقة - ينشئ أو يتحقق من token
 * @param {Object} req - طلب HTTP
 * @param {Object} res - رد HTTP  
 * @param {Function} next - دالة المتابعة
 */
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
        // إنشاء token جديد للضيف (مؤقت للتجربة)
        return res.status(401).json({ 
            error: 'مطلوب تسجيل الدخول',
            requireAuth: true 
        });
    }

    const decoded = verifyToken(token);
    if (!decoded) {
        return res.status(403).json({ 
            error: 'انتهت صلاحية الجلسة، يرجى إعادة تسجيل الدخول' 
        });
    }

    req.user = decoded;
    next();
}

// خدمة الملفات الثابتة
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// إعداد رفع الملفات
const upload = multer({
    dest: 'uploads/',
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max
    fileFilter: (req, file, cb) => {
        if (file.mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
            file.mimetype === 'application/vnd.ms-excel' ||
            file.originalname.endsWith('.xlsx') || 
            file.originalname.endsWith('.xls')) {
            cb(null, true);
        } else {
            cb(new Error('يجب أن يكون الملف من نوع Excel (.xlsx أو .xls)'), false);
        }
    }
});

// إعداد قاعدة البيانات المحدثة للاحتفاظ طويل المدى
const setupDatabase = async () => {
    try {
        if (process.env.DATABASE_URL) {
            // PostgreSQL الجداول الأساسية
            await db.query(`
                CREATE TABLE IF NOT EXISTS classes (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(255) UNIQUE NOT NULL,
                    qr_code TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    archived_at TIMESTAMP NULL,
                    deleted_by VARCHAR(255) NULL
                );
                
                CREATE TABLE IF NOT EXISTS students (
                    id SERIAL PRIMARY KEY,
                    class_id INTEGER REFERENCES classes(id) ON DELETE CASCADE,
                    name VARCHAR(255) NOT NULL,
                    student_number VARCHAR(50) UNIQUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    archived_at TIMESTAMP NULL,
                    deleted_by VARCHAR(255) NULL
                );
                
                CREATE TABLE IF NOT EXISTS followups (
                    id SERIAL PRIMARY KEY,
                    class_id INTEGER REFERENCES classes(id) ON DELETE CASCADE,
                    teacher_name VARCHAR(255) NOT NULL,
                    subject VARCHAR(255) NOT NULL,
                    date DATE NOT NULL,
                    participation_all VARCHAR(10) NOT NULL,
                    participation_students TEXT,
                    homework_all VARCHAR(10) NOT NULL,
                    homework_students TEXT,
                    notes TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    archived_at TIMESTAMP NULL,
                    deleted_by VARCHAR(255) NULL
                );
                
                CREATE TABLE IF NOT EXISTS parent_codes (
                    id SERIAL PRIMARY KEY,
                    student_number VARCHAR(50) UNIQUE NOT NULL,
                    parent_code VARCHAR(255) NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_login TIMESTAMP NULL,
                    archived_at TIMESTAMP NULL,
                    deleted_by VARCHAR(255) NULL
                );
                
                CREATE TABLE IF NOT EXISTS parent_comments (
                    id SERIAL PRIMARY KEY,
                    student_number VARCHAR(50) NOT NULL,
                    comment_text TEXT NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    deleted_at TIMESTAMP NULL,
                    archived_at TIMESTAMP NULL,
                    deleted_by VARCHAR(255) NULL
                );
                
                -- جداول الأرشفة والنُسخ الاحتياطي
                CREATE TABLE IF NOT EXISTS archived_data (
                    id SERIAL PRIMARY KEY,
                    table_name VARCHAR(100) NOT NULL,
                    record_id INTEGER NOT NULL,
                    archived_data JSONB NOT NULL,
                    original_data JSONB NOT NULL,
                    archive_reason VARCHAR(255) DEFAULT 'auto_archive',
                    archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    archived_by VARCHAR(255) DEFAULT 'system',
                    restore_requested_at TIMESTAMP NULL,
                    restore_requested_by VARCHAR(255) NULL,
                    is_permanently_deleted BOOLEAN DEFAULT FALSE,
                    permanent_delete_at TIMESTAMP NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                
                CREATE TABLE IF NOT EXISTS data_retention_policies (
                    id SERIAL PRIMARY KEY,
                    table_name VARCHAR(100) NOT NULL,
                    retention_days INTEGER NOT NULL,
                    auto_archive BOOLEAN DEFAULT TRUE,
                    auto_delete BOOLEAN DEFAULT FALSE,
                    policy_name VARCHAR(255) NOT NULL,
                    description TEXT,
                    is_active BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    created_by VARCHAR(255) DEFAULT 'system'
                );
                
                CREATE TABLE IF NOT EXISTS backup_logs (
                    id SERIAL PRIMARY KEY,
                    backup_type VARCHAR(50) NOT NULL, -- 'full', 'incremental', 'manual'
                    database_type VARCHAR(20) NOT NULL, -- 'postgresql', 'sqlite'
                    file_path TEXT NOT NULL,
                    file_size_mb DECIMAL(10,2),
                    records_count INTEGER DEFAULT 0,
                    backup_status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'in_progress', 'completed', 'failed'
                    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    completed_at TIMESTAMP NULL,
                    error_message TEXT NULL,
                    checksum TEXT NULL,
                    created_by VARCHAR(255) DEFAULT 'system',
                    metadata JSONB DEFAULT '{}'
                );
                
                -- فهارس محسنة للأداء
                CREATE INDEX IF NOT EXISTS idx_followups_date ON followups(date);
                CREATE INDEX IF NOT EXISTS idx_followups_class ON followups(class_id);
                CREATE INDEX IF NOT EXISTS idx_followups_archived ON followups(archived_at);
                CREATE INDEX IF NOT EXISTS idx_students_class_archived ON students(class_id, archived_at);
                CREATE INDEX IF NOT EXISTS idx_parent_codes_student ON parent_codes(student_number);
                CREATE INDEX IF NOT EXISTS idx_parent_comments_student ON parent_comments(student_number);
                CREATE INDEX IF NOT EXISTS idx_parent_comments_created ON parent_comments(created_at);
                CREATE INDEX IF NOT EXISTS idx_archived_data_table_record ON archived_data(table_name, record_id);
                CREATE INDEX IF NOT EXISTS idx_archived_data_archived_at ON archived_data(archived_at);
                CREATE INDEX IF NOT EXISTS idx_backup_logs_status ON backup_logs(backup_status);
                CREATE INDEX IF NOT EXISTS idx_backup_logs_created ON backup_logs(created_at);
                
                -- إدراج سياسات الاحتفاظ الافتراضية
                INSERT INTO data_retention_policies (table_name, retention_days, auto_archive, auto_delete, policy_name, description) VALUES
                ('followups', 365, TRUE, FALSE, 'سياسة متابعة الطلاب', 'الاحتفاظ بالمتابعات لمدة سنة واحدة'),
                ('parent_comments', 180, TRUE, TRUE, 'سياسة تعليقات أولياء الأمور', 'الاحتفاظ بالتعليقات لمدة 6 أشهر ثم حذف نهائي'),
                ('students', 0, FALSE, FALSE, 'سياسة بيانات الطلاب', 'عدم حذف بيانات الطلاب'),
                ('classes', 0, FALSE, FALSE, 'سياسة بيانات الفصول', 'عدم حذف بيانات الفصول'),
                ('parent_codes', 0, FALSE, FALSE, 'سياسة رموز أولياء الأمور', 'عدم حذف رموز أولياء الأمور')
                ON CONFLICT DO NOTHING;
            `);
        } else {
            // SQLite الجداول الأساسية
            db.exec(`
                CREATE TABLE IF NOT EXISTS classes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT UNIQUE NOT NULL,
                    qr_code TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    archived_at DATETIME NULL,
                    deleted_by TEXT NULL
                );
                
                CREATE TABLE IF NOT EXISTS students (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    class_id INTEGER,
                    name TEXT NOT NULL,
                    student_number TEXT UNIQUE,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    archived_at DATETIME NULL,
                    deleted_by TEXT NULL,
                    FOREIGN KEY (class_id) REFERENCES classes (id) ON DELETE CASCADE
                );
                
                CREATE TABLE IF NOT EXISTS followups (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    class_id INTEGER,
                    teacher_name TEXT NOT NULL,
                    subject TEXT NOT NULL,
                    date DATE NOT NULL,
                    participation_all TEXT NOT NULL,
                    participation_students TEXT,
                    homework_all TEXT NOT NULL,
                    homework_students TEXT,
                    notes TEXT,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    archived_at DATETIME NULL,
                    deleted_by TEXT NULL,
                    FOREIGN KEY (class_id) REFERENCES classes (id) ON DELETE CASCADE
                );
                
                CREATE TABLE IF NOT EXISTS parent_codes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_number TEXT UNIQUE NOT NULL,
                    parent_code TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    last_login DATETIME NULL,
                    archived_at DATETIME NULL,
                    deleted_by TEXT NULL
                );
                
                CREATE TABLE IF NOT EXISTS parent_comments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    student_number TEXT NOT NULL,
                    comment_text TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    deleted_at DATETIME NULL,
                    archived_at DATETIME NULL,
                    deleted_by TEXT NULL
                );
                
                -- جداول الأرشفة والنُسخ الاحتياطي
                CREATE TABLE IF NOT EXISTS archived_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    table_name TEXT NOT NULL,
                    record_id INTEGER NOT NULL,
                    archived_data TEXT NOT NULL, -- JSON as TEXT in SQLite
                    original_data TEXT NOT NULL, -- JSON as TEXT in SQLite
                    archive_reason TEXT DEFAULT 'auto_archive',
                    archived_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    archived_by TEXT DEFAULT 'system',
                    restore_requested_at DATETIME NULL,
                    restore_requested_by TEXT NULL,
                    is_permanently_deleted INTEGER DEFAULT 0,
                    permanent_delete_at DATETIME NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );
                
                CREATE TABLE IF NOT EXISTS data_retention_policies (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    table_name TEXT NOT NULL,
                    retention_days INTEGER NOT NULL,
                    auto_archive INTEGER DEFAULT 1,
                    auto_delete INTEGER DEFAULT 0,
                    policy_name TEXT NOT NULL,
                    description TEXT,
                    is_active INTEGER DEFAULT 1,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    created_by TEXT DEFAULT 'system'
                );
                
                CREATE TABLE IF NOT EXISTS backup_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    backup_type TEXT NOT NULL,
                    database_type TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    file_size_mb REAL DEFAULT 0,
                    records_count INTEGER DEFAULT 0,
                    backup_status TEXT DEFAULT 'pending',
                    started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    completed_at DATETIME NULL,
                    error_message TEXT NULL,
                    checksum TEXT NULL,
                    created_by TEXT DEFAULT 'system',
                    metadata TEXT DEFAULT '{}'
                );
                
                -- فهارس محسنة للأداء
                CREATE INDEX IF NOT EXISTS idx_followups_date ON followups(date);
                CREATE INDEX IF NOT EXISTS idx_followups_class ON followups(class_id);
                CREATE INDEX IF NOT EXISTS idx_followups_archived ON followups(archived_at);
                CREATE INDEX IF NOT EXISTS idx_students_class_archived ON students(class_id, archived_at);
                CREATE INDEX IF NOT EXISTS idx_parent_codes_student ON parent_codes(student_number);
                CREATE INDEX IF NOT EXISTS idx_parent_comments_student ON parent_comments(student_number);
                CREATE INDEX IF NOT EXISTS idx_parent_comments_created ON parent_comments(created_at);
                CREATE INDEX IF NOT EXISTS idx_archived_data_table_record ON archived_data(table_name, record_id);
                CREATE INDEX IF NOT EXISTS idx_archived_data_archived_at ON archived_data(archived_at);
                CREATE INDEX IF NOT EXISTS idx_backup_logs_status ON backup_logs(backup_status);
                CREATE INDEX IF NOT EXISTS idx_backup_logs_created ON backup_logs(created_at);
            `);
            
            // إدراج سياسات الاحتفاظ الافتراضية (SQLite)
            const policyCount = db.prepare('SELECT COUNT(*) as count FROM data_retention_policies').get().count;
            if (policyCount === 0) {
                const insertPolicy = db.prepare(`
                    INSERT INTO data_retention_policies 
                    (table_name, retention_days, auto_archive, auto_delete, policy_name, description) VALUES (?, ?, ?, ?, ?, ?)
                `);
                
                const policies = [
                    ('followups', 365, 1, 0, 'سياسة متابعة الطلاب', 'الاحتفاظ بالمتابعات لمدة سنة واحدة'),
                    ('parent_comments', 180, 1, 1, 'سياسة تعليقات أولياء الأمور', 'الاحتفاظ بالتعليقات لمدة 6 أشهر ثم حذف نهائي'),
                    ('students', 0, 0, 0, 'سياسة بيانات الطلاب', 'عدم حذف بيانات الطلاب'),
                    ('classes', 0, 0, 0, 'سياسة بيانات الفصول', 'عدم حذف بيانات الفصول'),
                    ('parent_codes', 0, 0, 0, 'سياسة رموز أولياء الأمور', 'عدم حذف رموز أولياء الأمور')
                ];
                
                const insertAll = db.transaction((policies) => {
                    for (const policy of policies) {
                        insertPolicy.run(...policy);
                    }
                });
                insertAll(policies);
            }
        }
        console.log('✅ تم إعداد قاعدة البيانات المحدثة بنجاح');
    } catch (error) {
        console.error('❌ خطأ في إعداد قاعدة البيانات:', error);
        process.exit(1);
    }
};

// إعداد قاعدة البيانات
setupDatabase();

// ================================
// وظائف الأرشفة والإدارة المتقدمة
// ================================

/**
 * أرشفة السجلات القديمة حسب السياسات المحددة
 */
async function archiveOldRecords() {
    try {
        console.log('🔄 بدء عملية أرشفة السجلات القديمة...');
        
        let tablesToArchive = [];
        
        // جلب سياسات الأرشفة النشطة
        if (process.env.DATABASE_URL) {
            const result = await db.query(`
                SELECT * FROM data_retention_policies 
                WHERE is_active = TRUE AND auto_archive = TRUE AND retention_days > 0
            `);
            tablesToArchive = result.rows;
        } else {
            tablesToArchive = db.prepare(`
                SELECT * FROM data_retention_policies 
                WHERE is_active = 1 AND auto_archive = 1 AND retention_days > 0
            `).all();
        }
        
        let archivedCount = 0;
        
        for (const policy of tablesToArchive) {
            try {
                const cutoffDate = dayjs().subtract(policy.retention_days, 'day').format('YYYY-MM-DD');
                const tableName = policy.table_name;
                
                // البحث عن السجلات للنسخ ثم الأرشفة
                if (process.env.DATABASE_URL) {
                    // PostgreSQL
                    await archiveTableRecords(tableName, cutoffDate, 'system', 'سياسة احتفاظ تلقائية');
                    archivedCount += 1;
                } else {
                    // SQLite
                    await archiveTableRecordsSQLite(tableName, cutoffDate, 'system', 'سياسة احتفاظ تلقائية');
                    archivedCount += 1;
                }
                
                console.log(`✅ تم أرشفة السجلات القديمة من جدول ${tableName}`);
            } catch (error) {
                console.error(`❌ خطأ في أرشفة جدول ${policy.table_name}:`, error);
            }
        }
        
        console.log(`🎉 تم أرشفة ${archivedCount} جدول بنجاح`);
    } catch (error) {
        console.error('❌ خطأ في أرشفة السجلات القديمة:', error);
    }
}

/**
 * أرشفة سجلات جدول معين (PostgreSQL)
 */
async function archiveTableRecords(tableName, cutoffDate, archivedBy, reason) {
    // أولاً: نسخ البيانات للسجلات القديمة
    const selectQuery = `
        SELECT * FROM ${tableName} 
        WHERE (archived_at IS NULL OR archived_at = '') 
        AND created_at::date < $1
    `;
    
    const result = await db.query(selectQuery, [cutoffDate]);
    
    if (result.rows.length === 0) return;
    
    // نسخ البيانات إلى جدول الأرشيف
    for (const record of result.rows) {
        const insertQuery = `
            INSERT INTO archived_data (table_name, record_id, archived_data, original_data, archive_reason, archived_by)
            VALUES ($1, $2, $3, $4, $5, $6)
        `;
        
        await db.query(insertQuery, [
            tableName,
            record.id,
            JSON.stringify(record),
            JSON.stringify(record),
            reason,
            archivedBy
        ]);
    }
    
    // ثانياً: تحديد السجلات كأرشيفية
    const updateQuery = `
        UPDATE ${tableName} 
        SET archived_at = CURRENT_TIMESTAMP, deleted_by = $1 
        WHERE archived_at IS NULL AND created_at::date < $2
    `;
    
    await db.query(updateQuery, [archivedBy, cutoffDate]);
}

/**
 * أرشفة سجلات جدول معين (SQLite)
 */
async function archiveTableRecordsSQLite(tableName, cutoffDate, archivedBy, reason) {
    // أولاً: نسخ البيانات للسجلات القديمة
    const selectStmt = db.prepare(`
        SELECT * FROM ${tableName} 
        WHERE (archived_at IS NULL OR archived_at = '') 
        AND date(created_at) < ?
    `);
    
    const records = selectStmt.all(cutoffDate);
    
    if (records.length === 0) return;
    
    // نسخ البيانات إلى جدول الأرشيف
    const insertStmt = db.prepare(`
        INSERT INTO archived_data (table_name, record_id, archived_data, original_data, archive_reason, archived_by)
        VALUES (?, ?, ?, ?, ?, ?)
    `);
    
    const insertAll = db.transaction((records) => {
        for (const record of records) {
            insertStmt.run(
                tableName,
                record.id,
                JSON.stringify(record),
                JSON.stringify(record),
                reason,
                archivedBy
            );
        }
    });
    insertAll(records);
    
    // ثانياً: تحديد السجلات كأرشيفية
    const updateStmt = db.prepare(`
        UPDATE ${tableName} 
        SET archived_at = CURRENT_TIMESTAMP, deleted_by = ? 
        WHERE archived_at IS NULL AND date(created_at) < ?
    `);
    
    updateStmt.run(archivedBy, cutoffDate);
}

/**
 * إنشاء نسخة احتياطية من قاعدة البيانات
 */
async function createBackup(backupType = 'manual') {
    try {
        console.log(`💾 بدء إنشاء نسخة احتياطية من نوع: ${backupType}`);
        
        const timestamp = dayjs().format('YYYY-MM-DD_HH-mm-ss');
        const backupDir = path.join(__dirname, 'backups');
        
        // إنشاء مجلد النسخ الاحتياطية إذا لم يكن موجوداً
        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir, { recursive: true });
        }
        
        const fileName = `backup_${backupType}_${timestamp}.${process.env.DATABASE_URL ? 'sql' : 'db'}`;
        const filePath = path.join(backupDir, fileName);
        
        // بدء تسجيل النسخة الاحتياطية
        let backupId;
        if (process.env.DATABASE_URL) {
            const result = await db.query(`
                INSERT INTO backup_logs (backup_type, database_type, file_path, backup_status)
                VALUES ($1, $2, $3, $4)
                RETURNING id
            `, [backupType, 'postgresql', filePath, 'in_progress']);
            backupId = result.rows[0].id;
        } else {
            const result = db.prepare(`
                INSERT INTO backup_logs (backup_type, database_type, file_path, backup_status)
                VALUES (?, ?, ?, ?)
            `).run(backupType, 'sqlite', filePath, 'in_progress');
            backupId = result.lastInsertRowid;
        }
        
        // إنشاء النسخة الاحتياطية
        if (process.env.DATABASE_URL) {
            // PostgreSQL backup
            const { exec } = require('child_process');
            const pg_dump_command = `pg_dump "${process.env.DATABASE_URL}" > "${filePath}"`;
            
            await new Promise((resolve, reject) => {
                exec(pg_dump_command, (error) => {
                    if (error) reject(error);
                    else resolve();
                });
            });
        } else {
            // SQLite backup
            fs.copyFileSync('classroom_system.db', filePath);
        }
        
        // تحديث معلومات النسخة الاحتياطية
        const stats = fs.statSync(filePath);
        const fileSizeMB = (stats.size / 1024 / 1024).toFixed(2);
        
        if (process.env.DATABASE_URL) {
            await db.query(`
                UPDATE backup_logs 
                SET file_size_mb = $1, backup_status = 'completed', completed_at = CURRENT_TIMESTAMP
                WHERE id = $2
            `, [fileSizeMB, backupId]);
        } else {
            db.prepare(`
                UPDATE backup_logs 
                SET file_size_mb = ?, backup_status = 'completed', completed_at = CURRENT_TIMESTAMP
                WHERE id = ?
            `).run(fileSizeMB, backupId);
        }
        
        console.log(`✅ تم إنشاء النسخة الاحتياطية بنجاح: ${filePath}`);
        return { backupId, filePath, fileSizeMB };
        
    } catch (error) {
        console.error('❌ خطأ في إنشاء النسخة الاحتياطية:', error);
        
        // تسجيل الخطأ في سجل النسخ الاحتياطية
        if (process.env.DATABASE_URL) {
            await db.query(`
                UPDATE backup_logs 
                SET backup_status = 'failed', error_message = $1, completed_at = CURRENT_TIMESTAMP
                WHERE id = $2
            `, [error.message, backupId]);
        } else {
            db.prepare(`
                UPDATE backup_logs 
                SET backup_status = 'failed', error_message = ?, completed_at = CURRENT_TIMESTAMP
                WHERE id = ?
            `).run(error.message, backupId);
        }
        
        throw error;
    }
}

// بدء خدمة الأرشفة والنسخ الاحتياطي
// لا يتم حذف السجلات تلقائياً بعد الآن
// archiveOldRecords(); // تم تعطيل الحذف التلقائي
console.log('📋 نظام الاحتفاظ طويل المدى نشط - لا يتم حذف البيانات تلقائياً');

// API Routes

// الحصول على جميع الفصول
app.get('/api/classes', async (req, res) => {
    try {
        let result;
        if (process.env.DATABASE_URL) {
            result = await db.query(`
                SELECT c.*, COUNT(s.id) as student_count
                FROM classes c
                LEFT JOIN students s ON c.id = s.class_id
                GROUP BY c.id
                ORDER BY c.name
            `);
            result = result.rows;
        } else {
            result = db.prepare(`
                SELECT c.*, COUNT(s.id) as student_count
                FROM classes c
                LEFT JOIN students s ON c.id = s.class_id
                GROUP BY c.id
                ORDER BY c.name
            `).all();
        }
        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// إنشاء فصل جديد
app.post('/api/classes', async (req, res) => {
    try {
        const { name } = req.body;
        if (!name) {
            return res.status(400).json({ error: 'اسم الفصل مطلوب' });
        }

        // إنشاء رمز QR للفصل
        const qrData = JSON.stringify({ className: name, timestamp: Date.now() });
        const qrCode = await QRCode.toDataURL(qrData);

        const result = db.prepare(`
            INSERT INTO classes (name, qr_code) VALUES (?, ?)
        `).run(name, qrCode);

        res.json({ 
            id: result.lastInsertRowid, 
            name, 
            qr_code: qrCode,
            student_count: 0 
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// رفع بيانات الطلاب
app.post('/api/upload-students', upload.single('studentsFile'), (req, res) => {
    try {
        const { classId } = req.body;
        if (!req.file) {
            return res.status(400).json({ error: 'يجب رفع ملف Excel' });
        }

        if (!classId) {
            return res.status(400).json({ error: 'معرف الفصل مطلوب' });
        }

        // قراءة ملف Excel
        const workbook = xlsx.readFile(req.file.path);
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const students = xlsx.utils.sheet_to_json(worksheet, { header: 1 });

        // التحقق من صحة البيانات
        if (students.length === 0) {
            return res.status(400).json({ error: 'الملف فارغ' });
        }

        // تنظيف بيانات الطلاب (العمود: الاسم، رقم الطالب)
        const studentsData = students
            .map((row, index) => ({
                name: row[0]?.toString().trim(),
                studentNumber: row[1]?.toString().trim() || null
            }))
            .filter(student => student.name && student.name.length > 0);

        if (studentsData.length === 0) {
            return res.status(400).json({ error: 'لا توجد بيانات طلاب صحيحة في الملف' });
        }

        // التحقق من تكرار أرقام الطلاب
        const studentNumbers = studentsData.filter(s => s.studentNumber).map(s => s.studentNumber);
        const uniqueNumbers = [...new Set(studentNumbers)];
        
        if (studentNumbers.length !== uniqueNumbers.length) {
            return res.status(400).json({ error: 'تكرار في أرقام الطلاب' });
        }

        // حذف الطلاب الحاليين للفصل
        db.prepare('DELETE FROM students WHERE class_id = ?').run(classId);

        // إدراج الطلاب الجدد
        const insertStmt = db.prepare(`
            INSERT INTO students (class_id, name, student_number) VALUES (?, ?, ?)
        `);

        const insert = db.transaction((studentsData) => {
            for (const student of studentsData) {
                insertStmt.run(classId, student.name, student.studentNumber);
            }
        });

        insert(studentsData);

        // حذف الملف المؤقت
        fs.unlinkSync(req.file.path);

        // إنشاء رموز ولي الأمر للطلاب الذين لديهم أرقام
        const studentsWithNumbers = studentsData.filter(s => s.studentNumber);
        if (studentsWithNumbers.length > 0) {
            const crypto = require('crypto');
            const insertParentCodeStmt = db.prepare(`
                INSERT INTO parent_codes (student_number, parent_code) VALUES (?, ?)
            `);

            const insertParentCodes = db.transaction((students) => {
                for (const student of students) {
                    const parentCode = crypto.randomBytes(6).toString('hex').toUpperCase();
                    insertParentCodeStmt.run(student.studentNumber, parentCode);
                }
            });

            insertParentCodes(studentsWithNumbers);
        }

        res.json({ 
            message: `تم رفع ${studentsData.length} طالب بنجاح`,
            count: studentsData.length,
            withParentCodes: studentsWithNumbers.length
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// الحصول على طلاب فصل معين
app.get('/api/classes/:id/students', (req, res) => {
    try {
        const { id } = req.params;
        const students = db.prepare(`
            SELECT * FROM students 
            WHERE class_id = ? 
            ORDER BY name
        `).all(id);
        res.json(students);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// إضافة طالب جديد
app.post('/api/students', (req, res) => {
    try {
        const { classId, name, studentNumber } = req.body;
        
        if (!classId || !name) {
            return res.status(400).json({ error: 'معرف الفصل والاسم مطلوبان' });
        }

        // التحقق من عدم تكرار رقم الطالب (إن وجد)
        if (studentNumber) {
            const existingStudent = db.prepare('SELECT id FROM students WHERE student_number = ?').get(studentNumber);
            if (existingStudent) {
                return res.status(400).json({ error: 'رقم الطالب موجود بالفعل' });
            }
        }

        const result = db.prepare(`
            INSERT INTO students (class_id, name, student_number) VALUES (?, ?, ?)
        `).run(classId, name, studentNumber || null);

        // إنشاء رمز ولي أمر إذا تم تحديد رقم طالب
        let parentCode = null;
        if (studentNumber) {
            const crypto = require('crypto');
            parentCode = crypto.randomBytes(6).toString('hex').toUpperCase();
            
            db.prepare(`
                INSERT INTO parent_codes (student_number, parent_code) VALUES (?, ?)
            `).run(studentNumber, parentCode);
        }

        res.json({ 
            id: result.lastInsertRowid,
            name,
            student_number: studentNumber || null,
            parent_code: parentCode,
            message: 'تم إضافة الطالب بنجاح' 
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// إرسال متابعة جديدة
app.post('/api/followups', (req, res) => {
    try {
        const { 
            classId, 
            teacherName, 
            subject, 
            date,
            participationAll, 
            participationStudents, 
            homeworkAll, 
            homeworkStudents, 
            notes 
        } = req.body;

        if (!classId || !teacherName || !subject || !date) {
            return res.status(400).json({ error: 'جميع الحقول الأساسية مطلوبة' });
        }

        const result = db.prepare(`
            INSERT INTO followups (
                class_id, teacher_name, subject, date,
                participation_all, participation_students,
                homework_all, homework_students, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
            classId, teacherName, subject, date,
            participationAll, participationStudents || null,
            homeworkAll, homeworkStudents || null,
            notes || null
        );

        res.json({ 
            id: result.lastInsertRowid,
            message: 'تم حفظ المتابعة بنجاح' 
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// الحصول على جميع المتابعات مع إمكانية الفلترة (محدث للعمل مع الأرشفة)
app.get('/api/followups', (req, res) => {
    try {
        const { startDate, endDate, classId, teacher, includeArchived = 'false' } = req.query;
        
        let query = `
            SELECT f.*, c.name as class_name
            FROM followups f
            JOIN classes c ON f.class_id = c.id
            WHERE 1=1
        `;
        
        const params = [];

        // تجاهل السجلات المؤرشفة افتراضياً
        if (includeArchived === 'false') {
            if (process.env.DATABASE_URL) {
                query += ' AND f.archived_at IS NULL';
            } else {
                query += ' AND f.archived_at IS NULL';
            }
        }

        if (startDate) {
            query += ' AND f.date >= ?';
            params.push(startDate);
        }

        if (endDate) {
            query += ' AND f.date <= ?';
            params.push(endDate);
        }

        if (classId) {
            query += ' AND f.class_id = ?';
            params.push(classId);
        }

        if (teacher) {
            if (process.env.DATABASE_URL) {
                query += ' AND f.teacher_name ILIKE ?';
            } else {
                query += ' AND f.teacher_name LIKE ?';
            }
            params.push(`%${teacher}%`);
        }

        query += ' ORDER BY f.date DESC, f.created_at DESC';

        let followups;
        if (process.env.DATABASE_URL) {
            const result = db.query(query, params);
            followups = result.rows;
        } else {
            followups = db.prepare(query).all(...params);
        }
        
        res.json(followups);
    } catch (error) {
        console.error('خطأ في جلب المتابعات:', error);
        res.status(500).json({ error: error.message });
    }
});

// إحصائيات سريعة محدثة
app.get('/api/stats', (req, res) => {
    try {
        const sevenDaysAgo = dayjs().subtract(7, 'day').format('YYYY-MM-DD');
        const thirtyDaysAgo = dayjs().subtract(30, 'day').format('YYYY-MM-DD');
        
        let stats;
        
        if (process.env.DATABASE_URL) {
            // PostgreSQL
            const totalFollowups = db.query('SELECT COUNT(*) as count FROM followups WHERE archived_at IS NULL');
            const thisWeekFollowups = db.query('SELECT COUNT(*) as count FROM followups WHERE date >= $1 AND archived_at IS NULL', [sevenDaysAgo]);
            const thisMonthFollowups = db.query('SELECT COUNT(*) as count FROM followups WHERE date >= $1 AND archived_at IS NULL', [thirtyDaysAgo]);
            const totalClasses = db.query('SELECT COUNT(*) as count FROM classes WHERE archived_at IS NULL');
            const activeStudents = db.query('SELECT COUNT(*) as count FROM students WHERE archived_at IS NULL');
            
            const averageParticipation = db.query(`
                SELECT AVG(CASE 
                    WHEN participation_all = 'نعم' THEN 100
                    WHEN participation_all = 'لا' THEN 0
                    ELSE 0
                END) as avg_participation
                FROM followups 
                WHERE date >= $1 AND archived_at IS NULL
            `, [sevenDaysAgo]);
            
            const archivedData = db.query('SELECT COUNT(*) as count FROM archived_data WHERE is_permanently_deleted = FALSE');
            
            Promise.all([totalFollowups, thisWeekFollowups, thisMonthFollowups, totalClasses, activeStudents, averageParticipation, archivedData])
                .then(([totalFollowupsRes, thisWeekFollowupsRes, thisMonthFollowupsRes, totalClassesRes, activeStudentsRes, averageParticipationRes, archivedDataRes]) => {
                    stats = {
                        totalFollowups: totalFollowupsRes.rows[0].count,
                        thisWeekFollowups: thisWeekFollowupsRes.rows[0].count,
                        thisMonthFollowups: thisMonthFollowupsRes.rows[0].count,
                        totalClasses: totalClassesRes.rows[0].count,
                        activeStudents: activeStudentsRes.rows[0].count,
                        averageParticipation: averageParticipationRes.rows[0].avg_participation || 0,
                        archivedRecords: archivedDataRes.rows[0].count,
                        databaseStatus: 'healthy'
                    };
                    res.json(stats);
                });
                
        } else {
            // SQLite
            stats = {
                totalFollowups: db.prepare('SELECT COUNT(*) as count FROM followups WHERE archived_at IS NULL').get().count,
                thisWeekFollowups: db.prepare('SELECT COUNT(*) as count FROM followups WHERE date >= ? AND archived_at IS NULL').get(sevenDaysAgo).count,
                thisMonthFollowups: db.prepare('SELECT COUNT(*) as count FROM followups WHERE date >= ? AND archived_at IS NULL').get(thirtyDaysAgo).count,
                totalClasses: db.prepare('SELECT COUNT(*) as count FROM classes WHERE archived_at IS NULL').get().count,
                activeStudents: db.prepare('SELECT COUNT(*) as count FROM students WHERE archived_at IS NULL').get().count,
                averageParticipation: db.prepare(`
                    SELECT AVG(CASE 
                        WHEN participation_all = 'نعم' THEN 100
                        WHEN participation_all = 'لا' THEN 0
                        ELSE 0
                    END) as avg_participation
                    FROM followups 
                    WHERE date >= ? AND archived_at IS NULL
                `).get(sevenDaysAgo).avg_participation || 0,
                archivedRecords: db.prepare('SELECT COUNT(*) as count FROM archived_data WHERE is_permanently_deleted = 0').get().count,
                databaseStatus: 'healthy'
            };

            res.json(stats);
        }
    } catch (error) {
        console.error('خطأ في جلب الإحصائيات:', error);
        res.status(500).json({ 
            error: 'خطأ في جلب الإحصائيات',
            databaseStatus: 'error'
        });
    }
});

// أرشفة متابعة بدلاً من حذفها نهائياً
app.delete('/api/followups/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { reason = 'طلب حذف يدوي' } = req.body;
        
        // التحقق من وجود المتابعة
        let followupExists;
        if (process.env.DATABASE_URL) {
            const result = await db.query('SELECT * FROM followups WHERE id = $1', [id]);
            followupExists = result.rows[0];
        } else {
            followupExists = db.prepare('SELECT * FROM followups WHERE id = ?').get(id);
        }
        
        if (!followupExists) {
            return res.status(404).json({ error: 'المتابعة غير موجودة' });
        }
        
        // أرشفة المتابعة بدلاً من حذفها
        const deletedBy = 'admin';
        
        if (process.env.DATABASE_URL) {
            // PostgreSQL
            await db.query(`
                UPDATE followups 
                SET archived_at = CURRENT_TIMESTAMP, deleted_by = $1
                WHERE id = $2
            `, [deletedBy, id]);
            
            // نسخ إلى جدول الأرشيف
            await db.query(`
                INSERT INTO archived_data (table_name, record_id, archived_data, original_data, archive_reason, archived_by)
                VALUES ($1, $2, $3, $4, $5, $6)
            `, ['followups', id, JSON.stringify(followupExists), JSON.stringify(followupExists), reason, deletedBy]);
            
        } else {
            // SQLite
            db.prepare(`
                UPDATE followups 
                SET archived_at = CURRENT_TIMESTAMP, deleted_by = ?
                WHERE id = ?
            `).run(deletedBy, id);
            
            // نسخ إلى جدول الأرشيف
            db.prepare(`
                INSERT INTO archived_data (table_name, record_id, archived_data, original_data, archive_reason, archived_by)
                VALUES (?, ?, ?, ?, ?, ?)
            `).run('followups', id, JSON.stringify(followupExists), JSON.stringify(followupExists), reason, deletedBy);
        }
        
        res.json({ 
            message: 'تم أرشفة المتابعة بنجاح (يمكن استعادتها لاحقاً)',
            archivedId: id,
            reason: reason
        });
    } catch (error) {
        console.error('خطأ في أرشفة المتابعة:', error);
        res.status(500).json({ error: error.message });
    }
});

// أرشفة فصل بدلاً من حذفه نهائياً
app.delete('/api/classes/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const { reason = 'طلب حذف يدوي' } = req.body;
        
        // التحقق من وجود الفصل
        let classExists;
        if (process.env.DATABASE_URL) {
            const result = await db.query('SELECT * FROM classes WHERE id = $1', [id]);
            classExists = result.rows[0];
        } else {
            classExists = db.prepare('SELECT * FROM classes WHERE id = ?').get(id);
        }
        
        if (!classExists) {
            return res.status(404).json({ error: 'الفصل غير موجود' });
        }
        
        const deletedBy = 'admin';
        
        // أرشفة الفصل
        if (process.env.DATABASE_URL) {
            // PostgreSQL
            await db.query(`
                UPDATE classes 
                SET archived_at = CURRENT_TIMESTAMP, deleted_by = $1
                WHERE id = $2
            `, [deletedBy, id]);
            
            // أرشفة الطلاب التابعين للفصل
            const students = await db.query('SELECT * FROM students WHERE class_id = $1', [id]);
            for (const student of students.rows) {
                await db.query(`
                    UPDATE students 
                    SET archived_at = CURRENT_TIMESTAMP, deleted_by = $1
                    WHERE id = $2
                `, [deletedBy, student.id]);
                
                await db.query(`
                    INSERT INTO archived_data (table_name, record_id, archived_data, original_data, archive_reason, archived_by)
                    VALUES ($1, $2, $3, $4, $5, $6)
                `, ['students', student.id, JSON.stringify(student), JSON.stringify(student), reason, deletedBy]);
            }
            
            // أرشفة المتابعات
            const followups = await db.query('SELECT * FROM followups WHERE class_id = $1', [id]);
            for (const followup of followups.rows) {
                await db.query(`
                    UPDATE followups 
                    SET archived_at = CURRENT_TIMESTAMP, deleted_by = $1
                    WHERE id = $2
                `, [deletedBy, followup.id]);
                
                await db.query(`
                    INSERT INTO archived_data (table_name, record_id, archived_data, original_data, archive_reason, archived_by)
                    VALUES ($1, $2, $3, $4, $5, $6)
                `, ['followups', followup.id, JSON.stringify(followup), JSON.stringify(followup), reason, deletedBy]);
            }
            
            // نسخ بيانات الفصل إلى الأرشيف
            await db.query(`
                INSERT INTO archived_data (table_name, record_id, archived_data, original_data, archive_reason, archived_by)
                VALUES ($1, $2, $3, $4, $5, $6)
            `, ['classes', id, JSON.stringify(classExists), JSON.stringify(classExists), reason, deletedBy]);
            
        } else {
            // SQLite
            db.prepare(`
                UPDATE classes 
                SET archived_at = CURRENT_TIMESTAMP, deleted_by = ?
                WHERE id = ?
            `).run(deletedBy, id);
            
            // أرشفة الطلاب التابعين للفصل
            const students = db.prepare('SELECT * FROM students WHERE class_id = ?').all(id);
            for (const student of students) {
                db.prepare(`
                    UPDATE students 
                    SET archived_at = CURRENT_TIMESTAMP, deleted_by = ?
                    WHERE id = ?
                `).run(deletedBy, student.id);
                
                db.prepare(`
                    INSERT INTO archived_data (table_name, record_id, archived_data, original_data, archive_reason, archived_by)
                    VALUES (?, ?, ?, ?, ?, ?)
                `).run('students', student.id, JSON.stringify(student), JSON.stringify(student), reason, deletedBy);
            }
            
            // أرشفة المتابعات
            const followups = db.prepare('SELECT * FROM followups WHERE class_id = ?').all(id);
            for (const followup of followups) {
                db.prepare(`
                    UPDATE followups 
                    SET archived_at = CURRENT_TIMESTAMP, deleted_by = ?
                    WHERE id = ?
                `).run(deletedBy, followup.id);
                
                db.prepare(`
                    INSERT INTO archived_data (table_name, record_id, archived_data, original_data, archive_reason, archived_by)
                    VALUES (?, ?, ?, ?, ?, ?)
                `).run('followups', followup.id, JSON.stringify(followup), JSON.stringify(followup), reason, deletedBy);
            }
            
            // نسخ بيانات الفصل إلى الأرشيف
            db.prepare(`
                INSERT INTO archived_data (table_name, record_id, archived_data, original_data, archive_reason, archived_by)
                VALUES (?, ?, ?, ?, ?, ?)
            `).run('classes', id, JSON.stringify(classExists), JSON.stringify(classExists), reason, deletedBy);
        }
        
        res.json({ 
            message: 'تم أرشفة الفصل وجميع بياناته بنجاح (يمكن استعادتها لاحقاً)',
            archivedClassId: id,
            archivedStudents: process.env.DATABASE_URL ? 
                (await db.query('SELECT COUNT(*) FROM students WHERE class_id = $1 AND archived_at IS NOT NULL', [id])).rows[0].count :
                db.prepare('SELECT COUNT(*) FROM students WHERE class_id = ? AND archived_at IS NOT NULL').get(id).count,
            archivedFollowups: process.env.DATABASE_URL ? 
                (await db.query('SELECT COUNT(*) FROM followups WHERE class_id = $1 AND archived_at IS NOT NULL', [id])).rows[0].count :
                db.prepare('SELECT COUNT(*) FROM followups WHERE class_id = ? AND archived_at IS NOT NULL').get(id).count,
            reason: reason
        });
    } catch (error) {
        console.error('خطأ في أرشفة الفصل:', error);
        res.status(500).json({ error: error.message });
    }
});

// ================================
// APIs الإدارة المتقدمة - الأرشفة والإدارة
// ================================

/**
 * أرشفة البيانات القديمة
 * POST /api/admin/archive-old-data
 */
app.post('/api/admin/archive-old-data', async (req, res) => {
    try {
        const { tableName, cutoffDate, reason = 'طلب يدوي من الإدارة' } = req.body;
        
        if (!tableName || !cutoffDate) {
            return res.status(400).json({ error: 'اسم الجدول وتاريخ القطع مطلوبان' });
        }
        
        const archivedBy = 'admin';
        let archivedRecordsCount = 0;
        
        try {
            if (process.env.DATABASE_URL) {
                // PostgreSQL
                await archiveTableRecords(tableName, cutoffDate, archivedBy, reason);
                
                const countResult = await db.query(`
                    SELECT COUNT(*) as count FROM archived_data 
                    WHERE table_name = $1 AND archived_at::date = CURRENT_DATE
                `, [tableName]);
                archivedRecordsCount = countResult.rows[0].count;
            } else {
                // SQLite
                await archiveTableRecordsSQLite(tableName, cutoffDate, archivedBy, reason);
                
                const count = db.prepare(`
                    SELECT COUNT(*) as count FROM archived_data 
                    WHERE table_name = ? AND date(archived_at) = date('now')
                `).get(tableName).count;
                archivedRecordsCount = count;
            }
            
            res.json({
                success: true,
                message: `تم أرشفة ${archivedRecordsCount} سجل من جدول ${tableName} بنجاح`,
                archivedRecordsCount,
                tableName,
                cutoffDate,
                reason
            });
            
        } catch (archiveError) {
            throw archiveError;
        }
        
    } catch (error) {
        console.error('خطأ في أرشفة البيانات:', error);
        res.status(500).json({ 
            error: 'خطأ في أرشفة البيانات',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * استعادة البيانات من الأرشيف
 * POST /api/admin/restore-data
 */
app.post('/api/admin/restore-data', async (req, res) => {
    try {
        const { archivedDataId } = req.body;
        
        if (!archivedDataId) {
            return res.status(400).json({ error: 'معرف البيانات المؤرشفة مطلوب' });
        }
        
        // جلب البيانات المؤرشفة
        let archivedRecord;
        if (process.env.DATABASE_URL) {
            const result = await db.query(`
                SELECT * FROM archived_data WHERE id = $1 AND is_permanently_deleted = FALSE
            `, [archivedDataId]);
            archivedRecord = result.rows[0];
        } else {
            archivedRecord = db.prepare(`
                SELECT * FROM archived_data WHERE id = ? AND is_permanently_deleted = 0
            `).get(archivedDataId);
        }
        
        if (!archivedRecord) {
            return res.status(404).json({ error: 'البيانات المؤرشفة غير موجودة أو محذوفة نهائياً' });
        }
        
        const tableName = archivedRecord.table_name;
        const recordData = JSON.parse(archivedRecord.archived_data);
        const recordId = archivedRecord.record_id;
        
        // استعادة البيانات
        if (process.env.DATABASE_URL) {
            // PostgreSQL
            const columns = Object.keys(recordData).filter(key => key !== 'id');
            const values = columns.map(col => recordData[col]);
            const placeholders = columns.map((_, index) => `$${index + 1}`).join(', ');
            
            const restoreQuery = `
                UPDATE ${tableName} 
                SET archived_at = NULL, deleted_by = NULL 
                WHERE id = $${columns.length + 1}
            `;
            
            await db.query(restoreQuery, [...values, recordId]);
            
            // تسجيل طلب الاستعادة
            await db.query(`
                UPDATE archived_data 
                SET restore_requested_at = CURRENT_TIMESTAMP, restore_requested_by = 'admin'
                WHERE id = $1
            `, [archivedDataId]);
            
        } else {
            // SQLite
            const columns = Object.keys(recordData).filter(key => key !== 'id');
            const values = columns.map(col => recordData[col]);
            
            const restoreQuery = `
                UPDATE ${tableName} 
                SET archived_at = NULL, deleted_by = NULL 
                WHERE id = ?
            `;
            
            db.prepare(restoreQuery).run(recordId);
            
            // تسجيل طلب الاستعادة
            db.prepare(`
                UPDATE archived_data 
                SET restore_requested_at = CURRENT_TIMESTAMP, restore_requested_by = 'admin'
                WHERE id = ?
            `).run(archivedDataId);
        }
        
        res.json({
            success: true,
            message: 'تم استعادة البيانات بنجاح',
            restoredRecord: {
                tableName,
                recordId,
                archivedDataId
            }
        });
        
    } catch (error) {
        console.error('خطأ في استعادة البيانات:', error);
        res.status(500).json({ 
            error: 'خطأ في استعادة البيانات',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * تنظيف البيانات المحذوفة نهائياً
 * POST /api/admin/cleanup-data
 */
app.post('/api/admin/cleanup-data', async (req, res) => {
    try {
        const { olderThanDays = 30, dryRun = false } = req.body;
        
        const cutoffDate = dayjs().subtract(olderThanDays, 'day').format('YYYY-MM-DD');
        
        // البحث عن البيانات المؤرشفة للحذف
        let recordsToDelete = [];
        if (process.env.DATABASE_URL) {
            const result = await db.query(`
                SELECT id, table_name, record_id, archived_at 
                FROM archived_data 
                WHERE is_permanently_deleted = FALSE 
                AND archived_at::date < $1
            `, [cutoffDate]);
            recordsToDelete = result.rows;
        } else {
            recordsToDelete = db.prepare(`
                SELECT id, table_name, record_id, archived_at 
                FROM archived_data 
                WHERE is_permanently_deleted = 0 
                AND date(archived_at) < ?
            `).all(cutoffDate);
        }
        
        if (dryRun) {
            return res.json({
                success: true,
                message: 'جرب (dry run) - لم يتم حذف أي بيانات',
                recordsToDelete: recordsToDelete.length,
                cutoffDate,
                records: recordsToDelete.slice(0, 10) // أول 10 سجلات للعرض
            });
        }
        
        let deletedCount = 0;
        
        // حذف البيانات نهائياً
        for (const record of recordsToDelete) {
            try {
                if (process.env.DATABASE_URL) {
                    // PostgreSQL
                    await db.query(`
                        UPDATE archived_data 
                        SET is_permanently_deleted = TRUE, permanent_delete_at = CURRENT_TIMESTAMP
                        WHERE id = $1
                    `, [record.id]);
                } else {
                    // SQLite
                    db.prepare(`
                        UPDATE archived_data 
                        SET is_permanently_deleted = 1, permanent_delete_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    `).run(record.id);
                }
                
                deletedCount++;
            } catch (deleteError) {
                console.error(`خطأ في حذف السجل ${record.id}:`, deleteError);
            }
        }
        
        res.json({
            success: true,
            message: `تم حذف ${deletedCount} سجل نهائياً`,
            deletedCount,
            totalRecordsFound: recordsToDelete.length,
            cutoffDate
        });
        
    } catch (error) {
        console.error('خطأ في تنظيف البيانات:', error);
        res.status(500).json({ 
            error: 'خطأ في تنظيف البيانات',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * إنشاء نسخة احتياطية
 * POST /api/admin/create-backup
 */
app.post('/api/admin/create-backup', async (req, res) => {
    try {
        const { backupType = 'manual' } = req.body;
        
        if (!['full', 'incremental', 'manual'].includes(backupType)) {
            return res.status(400).json({ error: 'نوع النسخة الاحتياطية غير صحيح' });
        }
        
        const backupResult = await createBackup(backupType);
        
        res.json({
            success: true,
            message: `تم إنشاء النسخة الاحتياطية بنجاح`,
            backup: backupResult,
            backupType
        });
        
    } catch (error) {
        console.error('خطأ في إنشاء النسخة الاحتياطية:', error);
        res.status(500).json({ 
            error: 'خطأ في إنشاء النسخة الاحتياطية',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * جلب سجلات النسخ الاحتياطية
 * GET /api/admin/backup-logs
 */
app.get('/api/admin/backup-logs', async (req, res) => {
    try {
        const { limit = 50, status } = req.query;
        
        let query = 'SELECT * FROM backup_logs ORDER BY created_at DESC LIMIT ?';
        let params = [parseInt(limit)];
        
        if (status) {
            if (process.env.DATABASE_URL) {
                query = 'SELECT * FROM backup_logs WHERE backup_status = $1 ORDER BY created_at DESC LIMIT $2';
            } else {
                query = 'SELECT * FROM backup_logs WHERE backup_status = ? ORDER BY created_at DESC LIMIT ?';
            }
            params.unshift(status);
        }
        
        let backupLogs;
        if (process.env.DATABASE_URL) {
            const result = await db.query(query, params);
            backupLogs = result.rows;
        } else {
            backupLogs = db.prepare(query).all(...params);
        }
        
        res.json({
            success: true,
            backupLogs: backupLogs.map(log => ({
                ...log,
                fileSizeFormatted: log.file_size_mb ? `${log.file_size_mb} MB` : 'N/A',
                duration: log.completed_at ? 
                    Math.round((new Date(log.completed_at) - new Date(log.started_at)) / 1000) + ' ثانية' : 
                    'قيد التنفيذ',
                createdAtFormatted: new Date(log.created_at).toLocaleString('ar-SA')
            }))
        });
        
    } catch (error) {
        console.error('خطأ في جلب سجلات النسخ الاحتياطية:', error);
        res.status(500).json({ 
            error: 'خطأ في جلب سجلات النسخ الاحتياطية',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * إحصائيات قاعدة البيانات المتقدمة
 * GET /api/admin/database-stats
 */
app.get('/api/admin/database-stats', async (req, res) => {
    try {
        let stats = {};
        
        if (process.env.DATABASE_URL) {
            // PostgreSQL
            const followupsStats = await db.query(`
                SELECT 
                    COUNT(*) as total,
                    COUNT(CASE WHEN archived_at IS NULL THEN 1 END) as active,
                    COUNT(CASE WHEN archived_at IS NOT NULL THEN 1 END) as archived,
                    COUNT(CASE WHEN date < CURRENT_DATE - INTERVAL '30 days' THEN 1 END) as old_records
                FROM followups
            `);
            
            const studentsStats = await db.query(`
                SELECT 
                    COUNT(*) as total,
                    COUNT(CASE WHEN archived_at IS NULL THEN 1 END) as active,
                    COUNT(CASE WHEN archived_at IS NOT NULL THEN 1 END) as archived
                FROM students
            `);
            
            const classesStats = await db.query(`
                SELECT 
                    COUNT(*) as total,
                    COUNT(CASE WHEN archived_at IS NULL THEN 1 END) as active,
                    COUNT(CASE WHEN archived_at IS NOT NULL THEN 1 END) as archived
                FROM classes
            `);
            
            const archivedDataStats = await db.query(`
                SELECT 
                    COUNT(*) as total_archived,
                    COUNT(CASE WHEN is_permanently_deleted = FALSE THEN 1 END) as recoverable,
                    COUNT(CASE WHEN is_permanently_deleted = TRUE THEN 1 END) as permanently_deleted,
                    COUNT(CASE WHEN date(archived_at) >= date('now', '-7 days') THEN 1 END) as archived_this_week
                FROM archived_data
            `);
            
            stats = {
                followups: followupsStats.rows[0],
                students: studentsStats.rows[0],
                classes: classesStats.rows[0],
                archivedData: archivedDataStats.rows[0],
                databaseType: 'postgresql'
            };
            
        } else {
            // SQLite
            const followupsStats = db.prepare(`
                SELECT 
                    COUNT(*) as total,
                    COUNT(CASE WHEN archived_at IS NULL THEN 1 END) as active,
                    COUNT(CASE WHEN archived_at IS NOT NULL THEN 1 END) as archived,
                    COUNT(CASE WHEN date < date('now', '-30 days') THEN 1 END) as old_records
                FROM followups
            `).get();
            
            const studentsStats = db.prepare(`
                SELECT 
                    COUNT(*) as total,
                    COUNT(CASE WHEN archived_at IS NULL THEN 1 END) as active,
                    COUNT(CASE WHEN archived_at IS NOT NULL THEN 1 END) as archived
                FROM students
            `).get();
            
            const classesStats = db.prepare(`
                SELECT 
                    COUNT(*) as total,
                    COUNT(CASE WHEN archived_at IS NULL THEN 1 END) as active,
                    COUNT(CASE WHEN archived_at IS NOT NULL THEN 1 END) as archived
                FROM classes
            `).get();
            
            const archivedDataStats = db.prepare(`
                SELECT 
                    COUNT(*) as total_archived,
                    COUNT(CASE WHEN is_permanently_deleted = 0 THEN 1 END) as recoverable,
                    COUNT(CASE WHEN is_permanently_deleted = 1 THEN 1 END) as permanently_deleted,
                    COUNT(CASE WHEN date(archived_at) >= date('now', '-7 days') THEN 1 END) as archived_this_week
                FROM archived_data
            `).get();
            
            stats = {
                followups: followupsStats,
                students: studentsStats,
                classes: classesStats,
                archivedData: archivedDataStats,
                databaseType: 'sqlite'
            };
        }
        
        res.json({
            success: true,
            stats,
            lastUpdated: new Date().toLocaleString('ar-SA')
        });
        
    } catch (error) {
        console.error('خطأ في جلب إحصائيات قاعدة البيانات:', error);
        res.status(500).json({ 
            error: 'خطأ في جلب إحصائيات قاعدة البيانات',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// ================================
// API بوابة ولي الأمر - المصادقة والبيانات
// ================================

/**
 * تسجيل دخول ولي الأمر
 * POST /api/parent/login
 * @body {string} studentNumber - رقم الطالب
 * @body {string} parentCode - الرقم السري لولي الأمر
 */
app.post('/api/parent/login', async (req, res) => {
    try {
        const { studentNumber, parentCode } = req.body;
        
        // التحقق من صحة البيانات المدخلة
        if (!studentNumber || !parentCode) {
            return res.status(400).json({ 
                error: 'رقم الطالب والرقم السري مطلوبان',
                required: {
                    studentNumber: 'رقم الطالب',
                    parentCode: 'الرقم السري'
                }
            });
        }

        // تنظيف وتطبيع البيانات
        const cleanStudentNumber = studentNumber.trim().toUpperCase();
        const cleanParentCode = parentCode.trim().toUpperCase();

        let result;
        if (process.env.DATABASE_URL) {
            // PostgreSQL - البحث عن الطالب ورقم ولي الأمر
            result = await db.query(`
                SELECT 
                    pc.*, 
                    s.name as student_name, 
                    s.id as student_id,
                    c.name as class_name,
                    c.id as class_id
                FROM parent_codes pc
                JOIN students s ON pc.student_number = s.student_number
                JOIN classes c ON s.class_id = c.id
                WHERE pc.student_number = $1 AND pc.parent_code = $2
            `, [cleanStudentNumber, cleanParentCode]);
            
            if (result.rows.length === 0) {
                return res.status(401).json({ 
                    error: 'رقم الطالب أو الرقم السري غير صحيح' 
                });
            }
            
            result = result.rows[0];
        } else {
            // SQLite - البحث عن الطالب ورقم ولي الأمر
            result = db.prepare(`
                SELECT 
                    pc.*, 
                    s.name as student_name, 
                    s.id as student_id,
                    c.name as class_name,
                    c.id as class_id
                FROM parent_codes pc
                JOIN students s ON pc.student_number = s.student_number
                JOIN classes c ON s.class_id = c.id
                WHERE pc.student_number = ? AND pc.parent_code = ?
            `).get(cleanStudentNumber, cleanParentCode);

            if (!result) {
                return res.status(401).json({ 
                    error: 'رقم الطالب أو الرقم السري غير صحيح' 
                });
            }
        }

        // إنشاء session token
        const tokenPayload = {
            userType: 'parent',
            studentNumber: result.student_number,
            studentName: result.student_name,
            classId: result.class_id,
            className: result.class_name,
            loginTime: Date.now()
        };

        const token = createToken(tokenPayload);

        // تحديث آخر تسجيل دخول
        if (process.env.DATABASE_URL) {
            await db.query(`
                UPDATE parent_codes 
                SET last_login = CURRENT_TIMESTAMP 
                WHERE student_number = $1
            `, [result.student_number]);
        } else {
            db.prepare(`
                UPDATE parent_codes 
                SET last_login = CURRENT_TIMESTAMP 
                WHERE student_number = ?
            `).run(result.student_number);
        }

        res.json({
            success: true,
            message: 'تم تسجيل الدخول بنجاح',
            token: token,
            data: {
                studentNumber: result.student_number,
                studentName: result.student_name,
                className: result.class_name,
                loginTime: new Date().toLocaleString('ar-SA')
            },
            expiresIn: JWT_EXPIRES_IN
        });

    } catch (error) {
        console.error('خطأ في تسجيل دخول ولي الأمر:', error);
        res.status(500).json({ 
            error: 'خطأ في الخادم، يرجى المحاولة مرة أخرى',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * الحصول على جميع بيانات الطالب
 * GET /api/parent/student-data/:studentNumber
 * @header Authorization: Bearer <token>
 */
app.get('/api/parent/student-data/:studentNumber', authenticateToken, async (req, res) => {
    try {
        const { studentNumber } = req.params;
        
        // التحقق من مطابقة token مع رقم الطالب المطلوب
        if (req.user.studentNumber !== studentNumber) {
            return res.status(403).json({ 
                error: 'غير مسموح بالوصول لبيانات هذا الطالب' 
            });
        }

        let result;
        if (process.env.DATABASE_URL) {
            // PostgreSQL - جلب بيانات الطالب والمتابعات
            result = await db.query(`
                WITH student_info AS (
                    SELECT 
                        s.id as student_id,
                        s.name as student_name,
                        s.student_number,
                        c.name as class_name,
                        c.id as class_id
                    FROM students s
                    JOIN classes c ON s.class_id = c.id
                    WHERE s.student_number = $1
                ),
                followups_data AS (
                    SELECT 
                        f.id,
                        f.date,
                        f.teacher_name,
                        f.subject,
                        f.participation_all,
                        f.participation_students,
                        f.homework_all,
                        f.homework_students,
                        f.notes,
                        f.created_at,
                        c.name as class_name
                    FROM followups f
                    JOIN student_info si ON f.class_id = si.class_id
                    JOIN classes c ON f.class_id = c.id
                    ORDER BY f.date DESC, f.created_at DESC
                    LIMIT 30 -- آخر 30 متابعة
                ),
                comments_data AS (
                    SELECT 
                        pc.id,
                        pc.comment_text,
                        pc.created_at
                    FROM parent_comments pc
                    WHERE pc.student_number = $1 AND pc.deleted_at IS NULL
                    ORDER BY pc.created_at DESC
                )
                SELECT 
                    json_build_object(
                        'student', (SELECT row_to_json(si) FROM student_info si),
                        'followups', (SELECT json_agg(fd) FROM followups_data fd),
                        'comments', (SELECT json_agg(cd) FROM comments_data cd),
                        'stats', (
                            SELECT json_build_object(
                                'totalFollowups', (SELECT COUNT(*) FROM followups_data),
                                'recentFollowups', (SELECT COUNT(*) FROM followups_data WHERE date >= CURRENT_DATE - INTERVAL '7 days'),
                                'participationRate', (
                                    SELECT ROUND(
                                        AVG(CASE 
                                            WHEN fd.participation_all = 'نعم' THEN 100
                                            WHEN fd.participation_all = 'لا' THEN 0
                                            ELSE NULL
                                        END), 1
                                    FROM followups_data fd
                                    WHERE fd.participation_all IN ('نعم', 'لا')
                                ),
                                'homeworkCompletionRate', (
                                    SELECT ROUND(
                                        AVG(CASE 
                                            WHEN fd.homework_all = 'نعم' THEN 100
                                            WHEN fd.homework_all = 'لا' THEN 0
                                            ELSE NULL
                                        END), 1
                                    FROM followups_data fd
                                    WHERE fd.homework_all IN ('نعم', 'لا')
                                )
                            )
                        )
                    ) as student_data
            `, [studentNumber]);
            
            result = result.rows[0]?.student_data || null;
        } else {
            // SQLite - جلب بيانات الطالب
            const studentInfo = db.prepare(`
                SELECT 
                    s.id as student_id,
                    s.name as student_name,
                    s.student_number,
                    c.name as class_name,
                    c.id as class_id
                FROM students s
                JOIN classes c ON s.class_id = c.id
                WHERE s.student_number = ?
            `).get(studentNumber);

            if (!studentInfo) {
                return res.status(404).json({ error: 'الطالب غير موجود' });
            }

            // جلب المتابعات (آخر 30 متابعة)
            const followups = db.prepare(`
                SELECT 
                    f.id,
                    f.date,
                    f.teacher_name,
                    f.subject,
                    f.participation_all,
                    f.participation_students,
                    f.homework_all,
                    f.homework_students,
                    f.notes,
                    f.created_at,
                    c.name as class_name
                FROM followups f
                JOIN classes c ON f.class_id = c.id
                WHERE f.class_id = ?
                ORDER BY f.date DESC, f.created_at DESC
                LIMIT 30
            `).all(studentInfo.class_id);

            // جلب التعليقات
            const comments = db.prepare(`
                SELECT 
                    pc.id,
                    pc.comment_text,
                    pc.created_at
                FROM parent_comments pc
                WHERE pc.student_number = ? AND pc.deleted_at IS NULL
                ORDER BY pc.created_at DESC
            `).all(studentNumber);

            // حساب الإحصائيات
            const recentFollowups = followups.filter(f => {
                const followupDate = new Date(f.date);
                const weekAgo = new Date();
                weekAgo.setDate(weekAgo.getDate() - 7);
                return followupDate >= weekAgo;
            });

            const participationData = followups.filter(f => f.participation_all === 'نعم' || f.participation_all === 'لا');
            const homeworkData = followups.filter(f => f.homework_all === 'نعم' || f.homework_all === 'لا');

            const participationRate = participationData.length > 0 
                ? Math.round((participationData.filter(f => f.participation_all === 'نعم').length / participationData.length) * 100 * 10) / 10
                : 0;

            const homeworkCompletionRate = homeworkData.length > 0
                ? Math.round((homeworkData.filter(f => f.homework_all === 'نعم').length / homeworkData.length) * 100 * 10) / 10
                : 0;

            result = {
                student: studentInfo,
                followups: followups,
                comments: comments,
                stats: {
                    totalFollowups: followups.length,
                    recentFollowups: recentFollowups.length,
                    participationRate: participationRate,
                    homeworkCompletionRate: homeworkCompletionRate
                }
            };
        }

        if (!result || !result.student) {
            return res.status(404).json({ error: 'بيانات الطالب غير موجودة' });
        }

        res.json({
            success: true,
            data: result,
            lastUpdated: new Date().toLocaleString('ar-SA')
        });

    } catch (error) {
        console.error('خطأ في جلب بيانات الطالب:', error);
        res.status(500).json({ 
            error: 'خطأ في الخادم، يرجى المحاولة مرة أخرى',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * إدارة تعليقات ولي الأمر
 * GET /api/parent/comments - جلب تعليقات الطالب
 * POST /api/parent/comments - إضافة تعليق جديد
 * DELETE /api/parent/comments/:commentId - حذف تعليق (للمديرين فقط)
 */
app.get('/api/parent/comments', authenticateToken, async (req, res) => {
    try {
        const { studentNumber } = req.query;
        
        if (!studentNumber) {
            return res.status(400).json({ error: 'رقم الطالب مطلوب' });
        }

        // التحقق من صحة الطالب
        let studentExists;
        if (process.env.DATABASE_URL) {
            const result = await db.query('SELECT student_number FROM students WHERE student_number = $1', [studentNumber]);
            studentExists = result.rows.length > 0;
        } else {
            studentExists = db.prepare('SELECT student_number FROM students WHERE student_number = ?').get(studentNumber);
        }

        if (!studentExists) {
            return res.status(404).json({ error: 'الطالب غير موجود' });
        }

        let result;
        if (process.env.DATABASE_URL) {
            result = await db.query(`
                SELECT pc.*, 
                       CASE WHEN pc.deleted_at IS NOT NULL THEN true ELSE false END as is_deleted
                FROM parent_comments pc
                WHERE pc.student_number = $1
                ORDER BY pc.created_at DESC
            `, [studentNumber]);
            result = result.rows;
        } else {
            result = db.prepare(`
                SELECT pc.*, 
                       CASE WHEN pc.deleted_at IS NOT NULL THEN 1 ELSE 0 END as is_deleted
                FROM parent_comments pc
                WHERE pc.student_number = ?
                ORDER BY pc.created_at DESC
            `).all(studentNumber);
        }

        res.json({
            success: true,
            comments: result.map(comment => ({
                ...comment,
                isDeleted: Boolean(comment.is_deleted),
                createdAtFormatted: new Date(comment.created_at).toLocaleString('ar-SA')
            }))
        });

    } catch (error) {
        console.error('خطأ في جلب التعليقات:', error);
        res.status(500).json({ 
            error: 'خطأ في الخادم، يرجى المحاولة مرة أخرى',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

app.post('/api/parent/comments', authenticateToken, async (req, res) => {
    try {
        const { commentText } = req.body;
        
        // التحقق من صحة البيانات
        if (!commentText || commentText.trim().length === 0) {
            return res.status(400).json({ error: 'نص التعليق مطلوب' });
        }

        if (commentText.trim().length > 1000) {
            return res.status(400).json({ error: 'التعليق طويل جداً (الحد الأقصى 1000 حرف)' });
        }

        // التحقق من صحة الطالب
        let studentExists;
        if (process.env.DATABASE_URL) {
            const result = await db.query('SELECT student_number FROM students WHERE student_number = $1', [req.user.studentNumber]);
            studentExists = result.rows.length > 0;
        } else {
            studentExists = db.prepare('SELECT student_number FROM students WHERE student_number = ?').get(req.user.studentNumber);
        }

        if (!studentExists) {
            return res.status(404).json({ error: 'الطالب غير موجود' });
        }

        const cleanComment = commentText.trim().replace(/</g, '&lt;').replace(/>/g, '&gt;');

        let result;
        if (process.env.DATABASE_URL) {
            const queryResult = await db.query(`
                INSERT INTO parent_comments (student_number, comment_text, created_at) 
                VALUES ($1, $2, CURRENT_TIMESTAMP) 
                RETURNING *
            `, [req.user.studentNumber, cleanComment]);
            result = queryResult.rows[0];
        } else {
            const queryResult = db.prepare(`
                INSERT INTO parent_comments (student_number, comment_text, created_at) 
                VALUES (?, ?, CURRENT_TIMESTAMP)
            `).run(req.user.studentNumber, cleanComment);
            
            result = db.prepare('SELECT * FROM parent_comments WHERE id = ?').get(queryResult.lastInsertRowid);
        }

        res.json({ 
            success: true,
            message: 'تم إضافة التعليق بنجاح',
            comment: {
                id: result.id,
                commentText: result.comment_text,
                createdAt: result.created_at,
                createdAtFormatted: new Date(result.created_at).toLocaleString('ar-SA')
            }
        });

    } catch (error) {
        console.error('خطأ في إضافة التعليق:', error);
        res.status(500).json({ 
            error: 'خطأ في الخادم، يرجى المحاولة مرة أخرى',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

app.delete('/api/parent/comments/:commentId', authenticateToken, async (req, res) => {
    try {
        // التحقق من أن المستخدم مدير (هنا يمكن إضافة نظام إدارة أفضل)
        if (req.user.userType !== 'admin' && req.user.userType !== 'teacher') {
            return res.status(403).json({ error: 'غير مسموح لك بحذف التعليقات' });
        }

        const { commentId } = req.params;
        
        if (!commentId || isNaN(commentId)) {
            return res.status(400).json({ error: 'معرف التعليق غير صحيح' });
        }

        // التحقق من وجود التعليق
        let commentExists;
        if (process.env.DATABASE_URL) {
            const result = await db.query('SELECT id FROM parent_comments WHERE id = $1', [commentId]);
            commentExists = result.rows.length > 0;
        } else {
            commentExists = db.prepare('SELECT id FROM parent_comments WHERE id = ?').get(commentId);
        }

        if (!commentExists) {
            return res.status(404).json({ error: 'التعليق غير موجود' });
        }

        // حذف التعليق (تحديث deleted_at)
        if (process.env.DATABASE_URL) {
            await db.query(`
                UPDATE parent_comments 
                SET deleted_at = CURRENT_TIMESTAMP 
                WHERE id = $1
            `, [commentId]);
        } else {
            db.prepare(`
                UPDATE parent_comments 
                SET deleted_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            `).run(commentId);
        }

        res.json({ 
            success: true,
            message: 'تم حذف التعليق بنجاح' 
        });

    } catch (error) {
        console.error('خطأ في حذف التعليق:', error);
        res.status(500).json({ 
            error: 'خطأ في الخادم، يرجى المحاولة مرة أخرى',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * تصدير بيانات الطالب
 * GET /api/parent/export-student-data/:studentNumber
 * @header Authorization: Bearer <token>
 */
app.get('/api/parent/export-student-data/:studentNumber', authenticateToken, async (req, res) => {
    try {
        const { studentNumber } = req.params;
        const { format = 'json', startDate, endDate } = req.query;
        
        // التحقق من مطابقة token مع رقم الطالب المطلوب
        if (req.user.studentNumber !== studentNumber) {
            return res.status(403).json({ 
                error: 'غير مسموح بتصدير بيانات هذا الطالب' 
            });
        }

        // التحقق من وجود الطالب
        let studentInfo;
        if (process.env.DATABASE_URL) {
            const result = await db.query(`
                SELECT s.*, c.name as class_name
                FROM students s
                JOIN classes c ON s.class_id = c.id
                WHERE s.student_number = $1
            `, [studentNumber]);
            studentInfo = result.rows[0];
        } else {
            studentInfo = db.prepare(`
                SELECT s.*, c.name as class_name
                FROM students s
                JOIN classes c ON s.class_id = c.id
                WHERE s.student_number = ?
            `).get(studentNumber);
        }

        if (!studentInfo) {
            return res.status(404).json({ error: 'الطالب غير موجود' });
        }

        // تحديد نطاق التواريخ للتصدير
        const defaultStartDate = startDate || dayjs().subtract(1, 'year').format('YYYY-MM-DD');
        const defaultEndDate = endDate || dayjs().format('YYYY-MM-DD');

        // جلب المتابعات
        let followupsData;
        if (process.env.DATABASE_URL) {
            const result = await db.query(`
                SELECT f.*, c.name as class_name
                FROM followups f
                JOIN classes c ON f.class_id = c.id
                WHERE f.class_id = $1 AND f.date >= $2 AND f.date <= $3
                ORDER BY f.date DESC, f.created_at DESC
            `, [studentInfo.class_id, defaultStartDate, defaultEndDate]);
            followupsData = result.rows;
        } else {
            followupsData = db.prepare(`
                SELECT f.*, c.name as class_name
                FROM followups f
                JOIN classes c ON f.class_id = c.id
                WHERE f.class_id = ? AND f.date >= ? AND f.date <= ?
                ORDER BY f.date DESC, f.created_at DESC
            `).all(studentInfo.class_id, defaultStartDate, defaultEndDate);
        }

        // جلب التعليقات
        let commentsData;
        if (process.env.DATABASE_URL) {
            const result = await db.query(`
                SELECT * FROM parent_comments
                WHERE student_number = $1 AND deleted_at IS NULL
                ORDER BY created_at DESC
            `, [studentNumber]);
            commentsData = result.rows;
        } else {
            commentsData = db.prepare(`
                SELECT * FROM parent_comments
                WHERE student_number = ? AND deleted_at IS NULL
                ORDER BY created_at DESC
            `).all(studentNumber);
        }

        // تجهيز البيانات للتصدير
        const exportData = {
            studentInfo: {
                id: studentInfo.id,
                name: studentInfo.name,
                studentNumber: studentInfo.student_number,
                className: studentInfo.class_name,
                createdAt: studentInfo.created_at
            },
            exportInfo: {
                exportDate: new Date().toISOString(),
                exportFormat: format,
                dateRange: {
                    startDate: defaultStartDate,
                    endDate: defaultEndDate
                },
                totalRecords: {
                    followups: followupsData.length,
                    comments: commentsData.length
                }
            },
            followups: followupsData.map(f => ({
                id: f.id,
                date: f.date,
                teacherName: f.teacher_name,
                subject: f.subject,
                participationAll: f.participation_all,
                participationStudents: f.participation_students,
                homeworkAll: f.homework_all,
                homeworkStudents: f.homework_students,
                notes: f.notes,
                createdAt: f.created_at
            })),
            comments: commentsData.map(c => ({
                id: c.id,
                commentText: c.comment_text,
                createdAt: c.created_at
            })),
            summary: {
                totalFollowups: followupsData.length,
                totalComments: commentsData.length,
                participationRate: followupsData.filter(f => f.participation_all === 'نعم').length / 
                    followupsData.filter(f => f.participation_all !== null).length * 100 || 0,
                homeworkCompletionRate: followupsData.filter(f => f.homework_all === 'نعم').length / 
                    followupsData.filter(f => f.homework_all !== null).length * 100 || 0
            }
        };

        // تنسيق الرد حسب نوع الملف المطلوب
        if (format === 'csv') {
            // تصدير كـ CSV
            const csv = convertToCSV(exportData);
            
            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="student_${studentNumber}_data_${dayjs().format('YYYY-MM-DD')}.csv"`);
            res.send(csv);
            
        } else if (format === 'excel') {
            // تصدير كـ Excel
            const workbook = xlsx.utils.book_new();
            
            // ورقة بيانات الطالب
            const studentSheetData = [
                ['بيانات الطالب'],
                ['الاسم', exportData.studentInfo.name],
                ['رقم الطالب', exportData.studentInfo.studentNumber],
                ['الفصل', exportData.studentInfo.className],
                ['تاريخ الإضافة', exportData.studentInfo.createdAt],
                [''],
                ['ملخص الإحصائيات'],
                ['إجمالي المتابعات', exportData.summary.totalFollowups],
                ['إجمالي التعليقات', exportData.summary.totalComments],
                ['معدل المشاركة', `${exportData.summary.participationRate.toFixed(1)}%`],
                ['معدل إنجاز الواجبات', `${exportData.summary.homeworkCompletionRate.toFixed(1)}%`]
            ];
            
            const studentSheet = xlsx.utils.aoa_to_sheet(studentSheetData);
            xlsx.utils.book_append_sheet(workbook, studentSheet, 'بيانات الطالب');
            
            // ورقة المتابعات
            if (exportData.followups.length > 0) {
                const followupsSheetData = [
                    ['التاريخ', 'اسم المعلم', 'المادة', 'المشاركة', 'الواجبات', 'الملاحظات']
                ];
                
                exportData.followups.forEach(f => {
                    followupsSheetData.push([
                        f.date,
                        f.teacherName,
                        f.subject,
                        f.participationAll,
                        f.homeworkAll,
                        f.notes || ''
                    ]);
                });
                
                const followupsSheet = xlsx.utils.aoa_to_sheet(followupsSheetData);
                xlsx.utils.book_append_sheet(workbook, followupsSheet, 'المتابعات');
            }
            
            // ورقة التعليقات
            if (exportData.comments.length > 0) {
                const commentsSheetData = [
                    ['تاريخ التعليق', 'نص التعليق']
                ];
                
                exportData.comments.forEach(c => {
                    commentsSheetData.push([
                        c.createdAt,
                        c.commentText
                    ]);
                });
                
                const commentsSheet = xlsx.utils.aoa_to_sheet(commentsSheetData);
                xlsx.utils.book_append_sheet(workbook, commentsSheet, 'التعليقات');
            }
            
            const excelBuffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });
            
            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            res.setHeader('Content-Disposition', `attachment; filename="student_${studentNumber}_data_${dayjs().format('YYYY-MM-DD')}.xlsx"`);
            res.send(excelBuffer);
            
        } else {
            // تصدير كـ JSON (افتراضي)
            res.setHeader('Content-Type', 'application/json; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="student_${studentNumber}_data_${dayjs().format('YYYY-MM-DD')}.json"`);
            res.json(exportData);
        }

    } catch (error) {
        console.error('خطأ في تصدير بيانات الطالب:', error);
        res.status(500).json({ 
            error: 'خطأ في تصدير بيانات الطالب',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * دالة مساعدة لتحويل البيانات إلى CSV
 */
function convertToCSV(data) {
    let csv = 'بيانات الطالب\n';
    
    csv += `الاسم,${data.studentInfo.name}\n`;
    csv += `رقم الطالب,${data.studentInfo.studentNumber}\n`;
    csv += `الفصل,${data.studentInfo.className}\n`;
    csv += `تاريخ الإضافة,${data.studentInfo.createdAt}\n\n`;
    
    csv += 'ملخص الإحصائيات\n';
    csv += `إجمالي المتابعات,${data.summary.totalFollowups}\n`;
    csv += `إجمالي التعليقات,${data.summary.totalComments}\n`;
    csv += `معدل المشاركة,${data.summary.participationRate.toFixed(1)}%\n`;
    csv += `معدل إنجاز الواجبات,${data.summary.homeworkCompletionRate.toFixed(1)}%\n\n`;
    
    if (data.followups.length > 0) {
        csv += 'المتابعات\n';
        csv += 'التاريخ,اسم المعلم,المادة,المشاركة,الواجبات,الملاحظات\n';
        
        data.followups.forEach(f => {
            csv += `${f.date},${f.teacherName},${f.subject},${f.participationAll},${f.homeworkAll},"${(f.notes || '').replace(/"/g, '""')}"\n`;
        });
        csv += '\n';
    }
    
    if (data.comments.length > 0) {
        csv += 'التعليقات\n';
        csv += 'تاريخ التعليق,نص التعليق\n';
        
        data.comments.forEach(c => {
            csv += `${c.createdAt},"${c.commentText.replace(/"/g, '""')}"\n`;
        });
    }
    
    return csv;
}

/**
 * التحقق من صحة token الجلسة
 * GET /api/parent/verify-token
 * @header Authorization: Bearer <token>
 */
app.get('/api/parent/verify-token', authenticateToken, async (req, res) => {
    try {
        // التحقق من وجود الطالب في قاعدة البيانات
        let studentExists;
        if (process.env.DATABASE_URL) {
            const result = await db.query(`
                SELECT s.name as student_name, c.name as class_name
                FROM students s
                JOIN classes c ON s.class_id = c.id
                WHERE s.student_number = $1
            `, [req.user.studentNumber]);
            studentExists = result.rows[0];
        } else {
            studentExists = db.prepare(`
                SELECT s.name as student_name, c.name as class_name
                FROM students s
                JOIN classes c ON s.class_id = c.id
                WHERE s.student_number = ?
            `).get(req.user.studentNumber);
        }

        if (!studentExists) {
            return res.status(401).json({ 
                error: 'انتهت صلاحية الجلسة',
                requireAuth: true 
            });
        }

        res.json({
            success: true,
            valid: true,
            user: {
                userType: req.user.userType,
                studentNumber: req.user.studentNumber,
                studentName: studentExists.student_name,
                className: studentExists.class_name,
                loginTime: req.user.loginTime ? new Date(req.user.loginTime).toLocaleString('ar-SA') : new Date().toLocaleString('ar-SA')
            }
        });

    } catch (error) {
        console.error('خطأ في التحقق من صحة الـ token:', error);
        res.status(500).json({ 
            error: 'خطأ في الخادم، يرجى المحاولة مرة أخرى',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * تسجيل خروج ولي الأمر
 * POST /api/parent/logout
 * @header Authorization: Bearer <token>
 */
app.post('/api/parent/logout', authenticateToken, (req, res) => {
    // هنا يمكن إضافة token إلى blacklist إذا كان ذلك مطلوباً
    // لكن حالياً سنعتبره تم بنجاح فقط
    
    res.json({
        success: true,
        message: 'تم تسجيل الخروج بنجاح'
    });
});

/**
 * الحصول على إحصائيات سريعة للطالب
 * GET /api/parent/student-stats/:studentNumber
 * @header Authorization: Bearer <token>
 */
app.get('/api/parent/student-stats/:studentNumber', authenticateToken, async (req, res) => {
    try {
        const { studentNumber } = req.params;
        
        // التحقق من مطابقة token مع رقم الطالب المطلوب
        if (req.user.studentNumber !== studentNumber) {
            return res.status(403).json({ 
                error: 'غير مسموح بالوصول لإحصائيات هذا الطالب' 
            });
        }

        const sevenDaysAgo = dayjs().subtract(7, 'day').format('YYYY-MM-DD');
        const thirtyDaysAgo = dayjs().subtract(30, 'day').format('YYYY-MM-DD');

        let result;
        if (process.env.DATABASE_URL) {
            // PostgreSQL - إحصائيات سريعة
            result = await db.query(`
                WITH student_class AS (
                    SELECT class_id FROM students WHERE student_number = $1
                ),
                stats AS (
                    SELECT 
                        (SELECT COUNT(*) FROM followups f 
                         JOIN student_class sc ON f.class_id = sc.class_id 
                         WHERE f.date >= $2) as followups_7_days,
                        (SELECT COUNT(*) FROM followups f 
                         JOIN student_class sc ON f.class_id = sc.class_id 
                         WHERE f.date >= $3) as followups_30_days,
                        (SELECT COUNT(*) FROM followups f 
                         JOIN student_class sc ON f.class_id = sc.class_id 
                         WHERE f.date >= $2 AND f.participation_all = 'نعم') as participation_yes,
                        (SELECT COUNT(*) FROM followups f 
                         JOIN student_class sc ON f.class_id = sc.class_id 
                         WHERE f.date >= $2 AND f.participation_all = 'لا') as participation_no,
                        (SELECT COUNT(*) FROM followups f 
                         JOIN student_class sc ON f.class_id = sc.class_id 
                         WHERE f.date >= $2 AND f.homework_all = 'نعم') as homework_yes,
                        (SELECT COUNT(*) FROM followups f 
                         JOIN student_class sc ON f.class_id = sc.class_id 
                         WHERE f.date >= $2 AND f.homework_all = 'لا') as homework_no,
                        (SELECT COUNT(*) FROM parent_comments pc 
                         WHERE pc.student_number = $1 AND pc.deleted_at IS NULL) as parent_comments
                    FROM student_class
                )
                SELECT * FROM stats
            `, [studentNumber, sevenDaysAgo, thirtyDaysAgo]);
            
            result = result.rows[0];
        } else {
            // SQLite - إحصائيات سريعة
            const studentClass = db.prepare('SELECT class_id FROM students WHERE student_number = ?').get(studentNumber);
            
            if (!studentClass) {
                return res.status(404).json({ error: 'الطالب غير موجود' });
            }

            const followups7Days = db.prepare(`
                SELECT COUNT(*) as count FROM followups 
                WHERE class_id = ? AND date >= ?
            `).get(studentClass.class_id, sevenDaysAgo).count;

            const followups30Days = db.prepare(`
                SELECT COUNT(*) as count FROM followups 
                WHERE class_id = ? AND date >= ?
            `).get(studentClass.class_id, thirtyDaysAgo).count;

            const participationYes = db.prepare(`
                SELECT COUNT(*) as count FROM followups 
                WHERE class_id = ? AND date >= ? AND participation_all = 'نعم'
            `).get(studentClass.class_id, sevenDaysAgo).count;

            const participationNo = db.prepare(`
                SELECT COUNT(*) as count FROM followups 
                WHERE class_id = ? AND date >= ? AND participation_all = 'لا'
            `).get(studentClass.class_id, sevenDaysAgo).count;

            const homeworkYes = db.prepare(`
                SELECT COUNT(*) as count FROM followups 
                WHERE class_id = ? AND date >= ? AND homework_all = 'نعم'
            `).get(studentClass.class_id, sevenDaysAgo).count;

            const homeworkNo = db.prepare(`
                SELECT COUNT(*) as count FROM followups 
                WHERE class_id = ? AND date >= ? AND homework_all = 'لا'
            `).get(studentClass.class_id, sevenDaysAgo).count;

            const parentComments = db.prepare(`
                SELECT COUNT(*) as count FROM parent_comments 
                WHERE student_number = ? AND deleted_at IS NULL
            `).get(studentNumber).count;

            result = {
                followups_7_days: followups7Days,
                followups_30_days: followups30Days,
                participation_yes: participationYes,
                participation_no: participationNo,
                homework_yes: homeworkYes,
                homework_no: homeworkNo,
                parent_comments: parentComments
            };
        }

        // حساب المعدلات
        const totalParticipation = result.participation_yes + result.participation_no;
        const participationRate = totalParticipation > 0 
            ? Math.round((result.participation_yes / totalParticipation) * 100 * 10) / 10 
            : 0;

        const totalHomework = result.homework_yes + result.homework_no;
        const homeworkRate = totalHomework > 0 
            ? Math.round((result.homework_yes / totalHomework) * 100 * 10) / 10 
            : 0;

        res.json({
            success: true,
            stats: {
                period: {
                    last7Days: sevenDaysAgo,
                    last30Days: thirtyDaysAgo
                },
                followups: {
                    last7Days: result.followups_7_days,
                    last30Days: result.followups_30_days
                },
                participation: {
                    yes: result.participation_yes,
                    no: result.participation_no,
                    rate: participationRate,
                    total: totalParticipation
                },
                homework: {
                    yes: result.homework_yes,
                    no: result.homework_no,
                    rate: homeworkRate,
                    total: totalHomework
                },
                comments: {
                    total: result.parent_comments
                },
                summary: {
                    activityLevel: result.followups_7_days > 5 ? 'عالي' : result.followups_7_days > 2 ? 'متوسط' : 'منخفض',
                    performanceStatus: participationRate >= 80 && homeworkRate >= 80 ? 'ممتاز' : participationRate >= 60 && homeworkRate >= 60 ? 'جيد' : 'يحتاج تحسين'
                }
            },
            calculatedAt: new Date().toLocaleString('ar-SA')
        });

    } catch (error) {
        console.error('خطأ في جلب إحصائيات الطالب:', error);
        res.status(500).json({ 
            error: 'خطأ في الخادم، يرجى المحاولة مرة أخرى',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

/**
 * فلترة متابعات الطالب
 * GET /api/parent/student-followups/:studentNumber/filter
 * @header Authorization: Bearer <token>
 * @query {string} startDate - تاريخ البداية
 * @query {string} endDate - تاريخ النهاية  
 * @query {string} subject - المادة
 * @query {string} teacher - اسم المعلم
 */
app.get('/api/parent/student-followups/:studentNumber/filter', authenticateToken, async (req, res) => {
    try {
        const { studentNumber } = req.params;
        const { startDate, endDate, subject, teacher } = req.query;
        
        // التحقق من مطابقة token مع رقم الطالب المطلوب
        if (req.user.studentNumber !== studentNumber) {
            return res.status(403).json({ 
                error: 'غير مسموح بالوصول لبيانات هذا الطالب' 
            });
        }

        // التحقق من صحة التواريخ
        const today = new Date().toISOString().split('T')[0];
        const defaultStartDate = startDate || dayjs().subtract(30, 'day').format('YYYY-MM-DD');
        const defaultEndDate = endDate || today;

        if (new Date(defaultStartDate) > new Date(defaultEndDate)) {
            return res.status(400).json({ 
                error: 'تاريخ البداية يجب أن يكون قبل تاريخ النهاية' 
            });
        }

        if (new Date(defaultEndDate) > new Date(today)) {
            return res.status(400).json({ 
                error: 'تاريخ النهاية لا يمكن أن يكون في المستقبل' 
            });
        }

        let result;
        if (process.env.DATABASE_URL) {
            // PostgreSQL - فلترة متابعات
            let query = `
                SELECT f.*, c.name as class_name
                FROM followups f
                JOIN students s ON f.class_id = s.class_id
                JOIN classes c ON f.class_id = c.id
                WHERE s.student_number = $1 AND f.date >= $2 AND f.date <= $3
            `;
            
            const params = [studentNumber, defaultStartDate, defaultEndDate];
            
            if (subject) {
                query += ` AND f.subject ILIKE $${params.length + 1}`;
                params.push(`%${subject}%`);
            }
            
            if (teacher) {
                query += ` AND f.teacher_name ILIKE $${params.length + 1}`;
                params.push(`%${teacher}%`);
            }
            
            query += ' ORDER BY f.date DESC, f.created_at DESC LIMIT 100';
            
            const queryResult = await db.query(query, params);
            result = queryResult.rows;
        } else {
            // SQLite - فلترة متابعات
            let query = `
                SELECT f.*, c.name as class_name
                FROM followups f
                JOIN students s ON f.class_id = s.class_id
                JOIN classes c ON f.class_id = c.id
                WHERE s.student_number = ? AND f.date >= ? AND f.date <= ?
            `;
            
            const params = [studentNumber, defaultStartDate, defaultEndDate];
            
            if (subject) {
                query += ` AND f.subject LIKE ?`;
                params.push(`%${subject}%`);
            }
            
            if (teacher) {
                query += ` AND f.teacher_name LIKE ?`;
                params.push(`%${teacher}%`);
            }
            
            query += ' ORDER BY f.date DESC, f.created_at DESC LIMIT 100';
            
            result = db.prepare(query).all(...params);
        }

        // تنسيق البيانات
        const formattedResults = result.map(followup => ({
            ...followup,
            dateFormatted: new Date(followup.date).toLocaleDateString('ar-SA'),
            createdAtFormatted: new Date(followup.created_at).toLocaleString('ar-SA'),
            participationRate: followup.participation_all === 'نعم' ? 100 : followup.participation_all === 'لا' ? 0 : null,
            homeworkRate: followup.homework_all === 'نعم' ? 100 : followup.homework_all === 'لا' ? 0 : null
        }));

        res.json({
            success: true,
            data: {
                followups: formattedResults,
                filters: {
                    startDate: defaultStartDate,
                    endDate: defaultEndDate,
                    subject: subject || null,
                    teacher: teacher || null
                },
                summary: {
                    total: formattedResults.length,
                    filtered: formattedResults.length,
                    dateRange: `${new Date(defaultStartDate).toLocaleDateString('ar-SA')} - ${new Date(defaultEndDate).toLocaleDateString('ar-SA')}`
                }
            }
        });

    } catch (error) {
        console.error('خطأ في فلترة متابعات الطالب:', error);
        res.status(500).json({ 
            error: 'خطأ في الخادم، يرجى المحاولة مرة أخرى',
            details: process.env.NODE_ENV === 'development' ? error.message : undefined
        });
    }
});

// التحقق من صحة رمز ولي الأمر
app.post('/api/parent/verify-code', async (req, res) => {
    try {
        const { parentCode } = req.body;
        
        if (!parentCode) {
            return res.status(400).json({ error: 'الرمز السري مطلوب' });
        }

        let result;
        if (process.env.DATABASE_URL) {
            result = await db.query(`
                SELECT pc.*, s.name as student_name, c.name as class_name
                FROM parent_codes pc
                JOIN students s ON pc.student_number = s.student_number
                JOIN classes c ON s.class_id = c.id
                WHERE pc.parent_code = $1
            `, [parentCode]);
            result = result.rows[0];
        } else {
            result = db.prepare(`
                SELECT pc.*, s.name as student_name, c.name as class_name
                FROM parent_codes pc
                JOIN students s ON pc.student_number = s.student_number
                JOIN classes c ON s.class_id = c.id
                WHERE pc.parent_code = ?
            `).get(parentCode);
        }

        if (!result) {
            return res.status(401).json({ error: 'رمز غير صحيح' });
        }

        res.json({
            success: true,
            studentNumber: result.student_number,
            studentName: result.student_name,
            className: result.class_name,
            createdAt: result.created_at
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// الحصول على متابعة الطالب
app.get('/api/parent/student-followups/:studentNumber', async (req, res) => {
    try {
        const { studentNumber } = req.params;
        
        let result;
        if (process.env.DATABASE_URL) {
            result = await db.query(`
                SELECT f.*, c.name as class_name
                FROM followups f
                JOIN students s ON f.class_id = s.class_id
                JOIN classes c ON f.class_id = c.id
                WHERE s.student_number = $1
                ORDER BY f.date DESC, f.created_at DESC
            `, [studentNumber]);
            result = result.rows;
        } else {
            result = db.prepare(`
                SELECT f.*, c.name as class_name
                FROM followups f
                JOIN students s ON f.class_id = s.class_id
                JOIN classes c ON f.class_id = c.id
                WHERE s.student_number = ?
                ORDER BY f.date DESC, f.created_at DESC
            `).all(studentNumber);
        }

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// إضافة تعليق جديد من ولي الأمر
app.post('/api/parent/comments', async (req, res) => {
    try {
        const { studentNumber, commentText } = req.body;
        
        if (!studentNumber || !commentText) {
            return res.status(400).json({ error: 'رقم الطالب والتعليق مطلوبان' });
        }

        // التحقق من وجود الطالب
        let studentExists;
        if (process.env.DATABASE_URL) {
            const result = await db.query('SELECT id FROM students WHERE student_number = $1', [studentNumber]);
            studentExists = result.rows.length > 0;
        } else {
            studentExists = db.prepare('SELECT id FROM students WHERE student_number = ?').get(studentNumber);
        }

        if (!studentExists) {
            return res.status(404).json({ error: 'الطالب غير موجود' });
        }

        let result;
        if (process.env.DATABASE_URL) {
            const queryResult = await db.query(`
                INSERT INTO parent_comments (student_number, comment_text) 
                VALUES ($1, $2) 
                RETURNING *
            `, [studentNumber, commentText]);
            result = queryResult.rows[0];
        } else {
            result = db.prepare(`
                INSERT INTO parent_comments (student_number, comment_text) 
                VALUES (?, ?)
            `).run(studentNumber, commentText);
        }

        res.json({ 
            message: 'تم إضافة التعليق بنجاح',
            id: process.env.DATABASE_URL ? result.id : result.lastInsertRowid
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// الحصول على تعليقات ولي الأمر
app.get('/api/parent/comments/:studentNumber', async (req, res) => {
    try {
        const { studentNumber } = req.params;
        
        let result;
        if (process.env.DATABASE_URL) {
            result = await db.query(`
                SELECT * FROM parent_comments 
                WHERE student_number = $1 AND deleted_at IS NULL
                ORDER BY created_at DESC
            `, [studentNumber]);
            result = result.rows;
        } else {
            result = db.prepare(`
                SELECT * FROM parent_comments 
                WHERE student_number = ? AND deleted_at IS NULL
                ORDER BY created_at DESC
            `).all(studentNumber);
        }

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// إعداد بيانات تجريبية لبوابة ولي الأمر (للمطورين فقط)
app.post('/api/parent/setup-data', async (req, res) => {
    try {
        // التحقق من وجود طلاب بدون أرقام
        let studentsWithoutNumbers;
        if (process.env.DATABASE_URL) {
            const result = await db.query(`
                SELECT id, name FROM students 
                WHERE student_number IS NULL 
                LIMIT 5
            `);
            studentsWithoutNumbers = result.rows;
        } else {
            studentsWithoutNumbers = db.prepare(`
                SELECT id, name FROM students 
                WHERE student_number IS NULL 
                LIMIT 5
            `).all();
        }

        if (studentsWithoutNumbers.length === 0) {
            return res.json({ message: 'لا توجد طلاب بدون أرقام' });
        }

        const crypto = require('crypto');

        const setupResults = [];
        
        for (const student of studentsWithoutNumbers) {
            // إنشاء رقم طالب عشوائي
            const studentNumber = crypto.randomBytes(4).toString('hex').toUpperCase();
            
            // إنشاء رمز ولي أمر عشوائي
            const parentCode = crypto.randomBytes(6).toString('hex').toUpperCase();

            // تحديث رقم الطالب
            if (process.env.DATABASE_URL) {
                await db.query('UPDATE students SET student_number = $1 WHERE id = $2', [studentNumber, student.id]);
                await db.query(`
                    INSERT INTO parent_codes (student_number, parent_code) 
                    VALUES ($1, $2)
                `, [studentNumber, parentCode]);
            } else {
                db.prepare('UPDATE students SET student_number = ? WHERE id = ?').run(studentNumber, student.id);
                db.prepare(`
                    INSERT INTO parent_codes (student_number, parent_code) 
                    VALUES (?, ?)
                `).run(studentNumber, parentCode);
            }

            setupResults.push({
                studentName: student.name,
                studentNumber: studentNumber,
                parentCode: parentCode
            });
        }

        res.json({
            message: `تم إعداد بيانات ${setupResults.length} طالب`,
            data: setupResults
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// إضافة تعليق من الإدارة (حذف التعليق)
app.delete('/api/parent/comments/:id', async (req, res) => {
    try {
        const { id } = req.params;
        
        if (process.env.DATABASE_URL) {
            await db.query(`
                UPDATE parent_comments 
                SET deleted_at = CURRENT_TIMESTAMP 
                WHERE id = $1
            `, [id]);
        } else {
            db.prepare(`
                UPDATE parent_comments 
                SET deleted_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            `).run(id);
        }

        res.json({ message: 'تم حذف التعليق بنجاح' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// الحصول على جميع تعليقات ولي الأمر (للإدارة)
app.get('/api/parent/all-comments', async (req, res) => {
    try {
        let result;
        if (process.env.DATABASE_URL) {
            result = await db.query(`
                SELECT pc.*, s.name as student_name, c.name as class_name
                FROM parent_comments pc
                JOIN students s ON pc.student_number = s.student_number
                JOIN classes c ON s.class_id = c.id
                ORDER BY pc.created_at DESC
            `);
            result = result.rows;
        } else {
            result = db.prepare(`
                SELECT pc.*, s.name as student_name, c.name as class_name
                FROM parent_comments pc
                JOIN students s ON pc.student_number = s.student_number
                JOIN classes c ON s.class_id = c.id
                ORDER BY pc.created_at DESC
            `).all();
        }

        res.json(result);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// تحديث بيانات الطالب برقم الطالب
app.put('/api/students/:id/number', async (req, res) => {
    try {
        const { id } = req.params;
        const { studentNumber } = req.body;
        
        if (!studentNumber) {
            return res.status(400).json({ error: 'رقم الطالب مطلوب' });
        }

        // التحقق من عدم تكرار رقم الطالب
        let existingStudent;
        if (process.env.DATABASE_URL) {
            const result = await db.query('SELECT id FROM students WHERE student_number = $1 AND id != $2', [studentNumber, id]);
            existingStudent = result.rows.length > 0;
        } else {
            existingStudent = db.prepare('SELECT id FROM students WHERE student_number = ? AND id != ?').get(studentNumber, id);
        }

        if (existingStudent) {
            return res.status(400).json({ error: 'رقم الطالب موجود بالفعل' });
        }

        if (process.env.DATABASE_URL) {
            await db.query('UPDATE students SET student_number = $1 WHERE id = $2', [studentNumber, id]);
        } else {
            db.prepare('UPDATE students SET student_number = ? WHERE id = ?').run(studentNumber, id);
        }

        res.json({ message: 'تم تحديث رقم الطالب بنجاح' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// صفحة رئيسية - إرسال ملف index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// صفحة المعلم
app.get('/teacher/:classId', (req, res) => {
    res.sendFile(path.join(__dirname, 'templates', 'teacher.html'));
});

// صفحة المشرف
app.get('/supervisor', (req, res) => {
    res.sendFile(path.join(__dirname, 'templates', 'supervisor.html'));
});

// إدارة الفصول - الواجهة المتقدمة
app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'templates', 'admin_enhanced.html'));
});

// إدارة الفصول - الواجهة الأساسية (للجوال)
app.get('/admin-basic', (req, res) => {
    res.sendFile(path.join(__dirname, 'templates', 'admin.html'));
});

// تشغيل الخادم
app.listen(PORT, () => {
    console.log(`🚀 الخادم يعمل على http://localhost:${PORT}`);
    console.log('📚 نظام المتابعة الصفية الذكي جاهز للاستخدام');
});

// تم تعطيل الحذف التلقائي للبيانات - النظام الجديد يحتفظ بالبيانات طويل المدى
// setInterval(deleteOldRecords, 60 * 60 * 1000); // تم التعطيل