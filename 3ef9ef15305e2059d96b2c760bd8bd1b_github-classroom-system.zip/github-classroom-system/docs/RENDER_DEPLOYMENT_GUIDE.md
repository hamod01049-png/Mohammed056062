# 🚀 دليل النشر على Render - نظام متابعة الفصول الدراسية

## 📋 خطوات النشر المفصلة

### المرحلة 1: تحضير الحساب
1. **إنشاء حساب على Render:**
   - اذهب إلى [https://render.com](https://render.com)
   - اضغط "Get Started for Free"
   - سجل الدخول باستخدام GitHub أو Google

### المرحلة 2: إعداد قاعدة البيانات PostgreSQL
1. **إنشاء قاعدة بيانات:**
   - من لوحة التحكم، اضغط "New +" 
   - اختر "PostgreSQL Database"
   - أدخل اسم قاعدة البيانات: `classroom-postgres`
   - اختر الخطة المجانية (Free)
   - اضغط "Create Database"

2. **تسجيل معلومات قاعدة البيانات:**
   ```
   Database Name: classroom-postgres
   Username: [ستحصل عليه من Render]
   Password: [ستحصل عليه من Render]
   Host: [ستحصل عليه من Render]
   Port: 5432 (افتراضي)
   Database URL: [ستحصل عليه من Render]
   ```

### المرحلة 3: إنشاء خدمة الويب
1. **ربط المستودع:**
   - من لوحة التحكم، اضغط "New +"
   - اختر "Web Service"
   - اختر "Build and deploy from a Git repository"
   - اربط مستودع GitHub (أنشئ مستودع جديد للنظام)

2. **رفع الملفات:**
   - قم برفع جميع ملفات النظام إلى مستودع GitHub
   - تأكد من وجود الملفات التالية:
     ```
     ✅ package.json
     ✅ render_server.js
     ✅ render.yaml
     ✅ server.js (للمرجع)
     ✅ templates/ (جميع ملفات HTML)
     ✅ public/ (CSS وJS)
     ```

### المرحلة 4: إعدادات الخدمة
1. **الإعدادات الأساسية:**
   ```
   Name: classroom-management-system
   Region: United States (East) [أو الأقرب]
   Branch: main
   Root Directory: / (الافتراضي)
   Runtime: Node
   Build Command: npm run render:build
   Start Command: npm start
   ```

2. **متغيرات البيئة المطلوبة:**
   ```
   NODE_ENV = production
   PORT = 10000
   DATABASE_URL = [من قاعدة البيانات PostgreSQL]
   JWT_SECRET = classroom_super_secret_2024
   CORS_ORIGIN = https://classroom-management-system.onrender.com
   ```

### المرحلة 5: النشر والاختبار
1. **بدء النشر:**
   - اضغط "Create Web Service"
   - انتظر انتهاء عملية البناء (5-10 دقائق)
   - سترى حالة "Live" عند نجاح النشر

2. **اختبار النظام:**
   - اذهب إلى الرابط المعروض
   - تأكد من ظهور رسالة الترحيب
   - جرب `/api/health` للتأكد من صحة النظام

## 🗄️ متغيرات البيئة التفصيلية

### متغيرات مطلوبة:
```bash
NODE_ENV=production
PORT=10000
DATABASE_URL=postgresql://username:password@host:5432/database_name
JWT_SECRET=classroom_super_secret_2024
CORS_ORIGIN=https://classroom-management-system.onrender.com
```

### متغيرات اختيارية:
```bash
SESSION_SECRET=another_super_secret_key
MAX_FILE_SIZE=10485760
UPLOAD_DIR=uploads
LOG_LEVEL=info
```

## 🔧 استكشاف الأخطاء

### مشاكل شائعة وحلولها:

**1. خطأ في البناء (Build Error):**
```
الحل: تأكد من وجود package.json وصحة scripts
تحقق من: npm run render:build يعمل محلياً
```

**2. فشل الاتصال بقاعدة البيانات:**
```
الحل: تأكد من صحة DATABASE_URL
تحقق من: إعدادات SSL في PostgreSQL
تحقق من: جدار الحماية على Render
```

**3. خطأ في المنفذ (Port Error):**
```
الحل: تأكد من استخدام process.env.PORT
تحقق من: Start Command الصحيح في Render
```

**4. مشاكل CORS:**
```
الحل: تأكد من CORS_ORIGIN الصحيح
تحقق من: الإعدادات في render_server.js
```

## 📊 مراقبة الأداء

### لوحة معلومات Render:
- **المقاييس المباشرة:** CPU، Memory، Network
- **السجلات:** logs مفصلة لكل طلب
- **المقاييس:**Response Time، Throughput

### تحسين الأداء:
```javascript
// مفاتيح للتحسين
- استخدام Redis للكاش
- تحسين استعلامات قاعدة البيانات
- ضغط الملفات الثابتة
- استخدام CDN للملفات
```

## 🔒 الأمان والنسخ الاحتياطية

### إعدادات الأمان:
```javascript
// مخفية في متغيرات البيئة
- JWT_SECRET: مفتاح التشفير
- CORS_ORIGIN: النطاقات المسموحة
- NODE_ENV: production
```

### النسخ الاحتياطي التلقائي:
- Render يوفر نسخ احتياطية تلقائية
- يمكن تفعيل النسخ اليدوية من لوحة التحكم
- الاحتفاظ بسجلات النسخ في جدول backup_logs

## 📈 ترقية الخطة

### الخطط المتاحة:
1. **Free:** اختبار وتطوير (محدود)
2. **Starter:** $7/شهر (متوسط الاستخدام)
3. **Standard:** $25/شهر (استخدام عالي)

### متى ترقية:
- **600+ طلب/دقيقة:** Starter
- **1000+ طلب/دقيقة:** Standard
- **قاعدة بيانات كبيرة:** Standard
- **موارد عالية:** Standard

## ✅ قائمة التحقق النهائية

قبل النشر، تأكد من:
- [ ] ملف package.json محدّث
- [ ] render_server.js يعمل محلياً
- [ ] متغيرات البيئة محددة
- [ ] قاعدة البيانات PostgreSQL منشأة
- [ ] جميع الملفات مرفوعة
- [ ] اختبار /api/health يعمل
- [ ] واجهة النظام تظهر بشكل صحيح

## 🆘 الدعم والمساعدة

### موارد مفيدة:
- **وثائق Render:** https://render.com/docs
- **دعم Render:** https://render.com/support
- **Discord المجتمع:** https://discord.gg/render

### معلومات المهمة:
```
رابط النظام: https://classroom-management-system.onrender.com
حالة الخدمة: Monitor من لوحة Render
إشعار الطوارئ: Email/SMS من Render
```

---

**تم إنشاء هذا الدليل بواسطة MiniMax Agent**
**التاريخ: 2025-11-04**
**النظام: Smart Classroom Management System v2.0