#!/bin/bash

# 🔥 اختبار سريع لنظام الفصول الذكية

echo "🚀 اختبار نظام الفصول الدراسية الذكية"
echo "================================================"

# فحص الملفات الأساسية
echo "📁 فحص الملفات الأساسية..."

required_files=(
  "server.js"
  "render_server.js" 
  "package.json"
  "render.yaml"
  "README.md"
)

missing_files=()

for file in "${required_files[@]}"; do
  if [ -f "$file" ]; then
    echo "✅ $file"
  else
    echo "❌ $file - مفقود!"
    missing_files+=("$file")
  fi
done

# فحص المجلدات
echo ""
echo "📂 فحص المجلدات..."

required_dirs=(
  "templates"
  "public"
  "public/css"
  "public/js"
)

missing_dirs=()

for dir in "${required_dirs[@]}"; do
  if [ -d "$dir" ]; then
    echo "✅ $dir/"
  else
    echo "❌ $dir/ - مفقود!"
    missing_dirs+=("$dir")
  fi
done

# فحص package.json
echo ""
echo "📋 فحص package.json..."

if [ -f "package.json" ]; then
  # فحص scripts
  if grep -q '"start"' package.json; then
    echo "✅ start script موجود"
  else
    echo "❌ start script مفقود"
  fi
  
  # فحص render:build
  if grep -q '"render:build"' package.json; then
    echo "✅ render:build script موجود"
  else
    echo "❌ render:build script مفقود"
  fi
  
  # فحص PostgreSQL
  if grep -q '"pg"' package.json; then
    echo "✅ PostgreSQL dependency موجود"
  else
    echo "❌ PostgreSQL dependency مفقود"
  fi
fi

# فحص render_server.js
echo ""
echo "🔧 فحص render_server.js..."

if [ -f "render_server.js" ]; then
  # فحص متغيرات البيئة
  if grep -q 'process.env.DATABASE_URL' render_server.js; then
    echo "✅ دعم DATABASE_URL موجود"
  else
    echo "❌ دعم DATABASE_URL مفقود"
  fi
  
  # فحص PORT
  if grep -q 'process.env.PORT' render_server.js; then
    echo "✅ دعم PORT موجود"
  else
    echo "❌ دعم PORT مفقود"
  fi
  
  # فحص /api/health
  if grep -q '/api/health' render_server.js; then
    echo "✅ health endpoint موجود"
  else
    echo "❌ health endpoint مفقود"
  fi
fi

# فحص render.yaml
echo ""
echo "⚙️ فحص render.yaml..."

if [ -f "render.yaml" ]; then
  # فحص Node
  if grep -q 'node' render.yaml; then
    echo "✅ Node environment محدد"
  else
    echo "❌ Node environment غير محدد"
  fi
  
  # فحص PostgreSQL
  if grep -q 'PostgreSQL' render.yaml; then
    echo "✅ PostgreSQL database مربوط"
  else
    echo "❌ PostgreSQL database غير مربوط"
  fi
fi

# ملخص النتائج
echo ""
echo "📊 ملخص النتائج"
echo "================================================"

if [ ${#missing_files[@]} -eq 0 ] && [ ${#missing_dirs[@]} -eq 0 ]; then
  echo "🎉 جميع الملفات المطلوبة موجودة!"
  echo ""
  echo "🚀 النظام جاهز للنشر على Render!"
  echo ""
  echo "📝 الخطوات التالية:"
  echo "1. رفع الملفات إلى GitHub"
  echo "2. إنشاء PostgreSQL في Render"
  echo "3. ربط Render بـ GitHub repository"
  echo "4. إعداد متغيرات البيئة"
  echo "5. نشر الخدمة"
  echo ""
  echo "📚 راجع: QUICK_RENDER_START.md"
else
  echo "⚠️ ملفات مفقودة:"
  for file in "${missing_files[@]}"; do
    echo "   - $file"
  done
  
  for dir in "${missing_dirs[@]}"; do
    echo "   - $dir/"
  done
  
  echo ""
  echo "🔧 يرجى إكمال الملفات المفقودة قبل النشر"
fi

echo ""
echo "🔍 تم بواسطة: $(date)"
echo "📅 التاريخ: $(date '+%Y-%m-%d %H:%M:%S')"

# النهاية
if [ ${#missing_files[@]} -eq 0 ] && [ ${#missing_dirs[@]} -eq 0 ]; then
  exit 0
else
  exit 1
fi