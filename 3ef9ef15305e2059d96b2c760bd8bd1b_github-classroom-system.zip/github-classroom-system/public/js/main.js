// متغيرات عامة
const API_BASE = window.location.origin;
let classesData = [];

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', function() {
    loadClasses();
    setupEventListeners();
});

// إعداد مستمعي الأحداث
function setupEventListeners() {
    // زر إعادة التحديث
    document.getElementById('refreshBtn')?.addEventListener('click', loadClasses);
    
    // روابط التنقل
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('href');
            navigateTo(target);
        });
    });
}

// تحميل الفصول
async function loadClasses() {
    const loadingEl = document.getElementById('loading');
    const gridEl = document.getElementById('classGrid');
    
    try {
        loadingEl.style.display = 'block';
        gridEl.style.display = 'none';
        
        const response = await fetch(`${API_BASE}/api/classes`);
        const classes = await response.json();
        
        if (response.ok) {
            classesData = classes;
            displayClasses(classes);
            updateStats(classes);
        } else {
            throw new Error(classes.error || 'فشل في تحميل الفصول');
        }
    } catch (error) {
        showAlert('error', error.message);
    } finally {
        loadingEl.style.display = 'none';
        gridEl.style.display = 'grid';
    }
}

// عرض الفصول
function displayClasses(classes) {
    const gridEl = document.getElementById('classGrid');
    
    if (classes.length === 0) {
        gridEl.innerHTML = `
            <div class="card text-center" style="grid-column: 1 / -1;">
                <h3>لا توجد فصول مسجلة</h3>
                <p class="text-secondary">ابدأ بإضافة فصل جديد من لوحة الإدارة</p>
                <a href="/admin" class="btn btn-primary">إضافة فصل جديد</a>
            </div>
        `;
        return;
    }
    
    gridEl.innerHTML = classes.map(cls => `
        <div class="class-card" onclick="navigateToTeacher(${cls.id})">
            <div class="class-name">${escapeHtml(cls.name)}</div>
            <div class="qr-code">
                ${cls.qr_code ? `<img src="${cls.qr_code}" alt="رمز QR" loading="lazy">` : `
                    <div style="width: 100%; height: 100%; background: var(--primary-100); 
                                display: flex; align-items: center; justify-content: center; 
                                color: var(--text-secondary); font-size: 12px;">
                        لا يوجد رمز QR
                    </div>
                `}
            </div>
            <div class="class-stats">
                ${cls.student_count || 0} طالب
            </div>
        </div>
    `).join('');
}

// تحديث الإحصائيات
function updateStats(classes) {
    const statsEl = document.getElementById('statsContainer');
    if (!statsEl) return;
    
    const totalStudents = classes.reduce((sum, cls) => sum + (cls.student_count || 0), 0);
    
    statsEl.innerHTML = `
        <div class="stats-grid">
            <div class="stat-card">
                <span class="stat-number">${classes.length}</span>
                <div class="stat-label">إجمالي الفصول</div>
            </div>
            <div class="stat-card">
                <span class="stat-number">${totalStudents}</span>
                <div class="stat-label">إجمالي الطلاب</div>
            </div>
            <div class="stat-card">
                <span class="stat-number">-</span>
                <div class="stat-label">المتابعات اليوم</div>
            </div>
        </div>
    `;
}

// الانتقال إلى صفحة المعلم
function navigateToTeacher(classId) {
    window.location.href = `/teacher/${classId}`;
}

// الانتقال إلى صفحة أخرى
function navigateTo(path) {
    window.location.href = path;
}

// إظهار تنبيه
function showAlert(type, message) {
    const alertHtml = `
        <div class="alert alert-${type}" role="alert">
            ${escapeHtml(message)}
            <button type="button" class="close" onclick="this.parentElement.remove()">
                <span>&times;</span>
            </button>
        </div>
    `;
    
    const container = document.getElementById('alerts');
    if (container) {
        container.innerHTML = alertHtml;
        
        // إخفاء التنبيه تلقائياً بعد 5 ثواني
        setTimeout(() => {
            const alert = container.querySelector('.alert');
            if (alert) {
                alert.style.opacity = '0';
                setTimeout(() => alert.remove(), 300);
            }
        }, 5000);
    }
}

// حماية من XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// تحديث الوقت الحالي
function updateCurrentTime() {
    const now = new Date();
    const timeString = now.toLocaleString('ar-SA', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
    
    const timeEl = document.getElementById('currentTime');
    if (timeEl) {
        timeEl.textContent = timeString;
    }
}

// تشغيل تحديث الوقت
updateCurrentTime();
setInterval(updateCurrentTime, 60000); // كل دقيقة

// وظائف إضافية للتصدير
window.navigateToTeacher = navigateToTeacher;
window.showAlert = showAlert;
window.escapeHtml = escapeHtml;