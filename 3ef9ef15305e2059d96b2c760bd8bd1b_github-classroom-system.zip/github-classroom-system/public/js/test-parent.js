/**
 * ملف اختبار بوابة ولي الأمر
 * اختبار وظائف API والتصميم
 */

const ParentPortalTest = {
    // إعدادات الاختبار
    API_BASE: window.location.origin,
    testStudentNumber: 'A1B2C3D4',
    testParentCode: 'E5F6G7H8I9',

    // متغيرات الاختبار
    testResults: [],
    currentTest: 0,

    // تشغيل جميع الاختبارات
    async runAllTests() {
        console.log('🧪 بدء اختبار بوابة ولي الأمر');
        console.log('=====================================');
        
        this.testResults = [];
        this.currentTest = 0;

        const tests = [
            this.testPageLoad,
            this.testAPIStructure,
            this.testLoginForm,
            this.testCSSStyles,
            this.testJavaScriptFunctions,
            this.testResponsiveDesign,
            this.testAccessibility,
            this.testPerformance
        ];

        for (let test of tests) {
            await test.call(this);
        }

        this.showTestResults();
    },

    // اختبار تحميل الصفحة
    async testPageLoad() {
        console.log('\n📄 اختبار تحميل الصفحة...');
        
        try {
            const html = document.documentElement.outerHTML;
            const hasRTL = html.includes('dir="rtl"');
            const hasArabic = html.includes('lang="ar"');
            const hasTitle = html.includes('بوابة ولي الأمر');
            const hasParentCSS = html.includes('/css/parent.css');
            const hasParentJS = html.includes('/js/parent.js');

            const results = {
                rtl_support: hasRTL,
                arabic_language: hasArabic,
                correct_title: hasTitle,
                css_linked: hasParentCSS,
                js_linked: hasParentJS
            };

            this.addTestResult('تحميل الصفحة', results, Object.values(results).every(r => r));
        } catch (error) {
            this.addTestResult('تحميل الصفحة', { error: error.message }, false);
        }
    },

    // اختبار هيكل API
    async testAPIStructure() {
        console.log('\n🔌 اختبار هيكل API...');
        
        try {
            const endpoints = [
                '/api/parent/verify-code',
                `/api/parent/student-followups/${this.testStudentNumber}`,
                '/api/parent/comments',
                `/api/parent/comments/${this.testStudentNumber}`
            ];

            const results = {};
            for (let endpoint of endpoints) {
                try {
                    const response = await fetch(this.API_BASE + endpoint, {
                        method: 'OPTIONS'
                    });
                    results[endpoint] = response.status !== 404;
                } catch (error) {
                    results[endpoint] = false;
                }
            }

            this.addTestResult('هيكل API', results, Object.values(results).some(r => r));
        } catch (error) {
            this.addTestResult('هيكل API', { error: error.message }, false);
        }
    },

    // اختبار نموذج تسجيل الدخول
    async testLoginForm() {
        console.log('\n🔐 اختبار نموذج تسجيل الدخول...');
        
        try {
            const loginForm = document.getElementById('loginForm');
            const studentInput = document.getElementById('studentNumber');
            const codeInput = document.getElementById('parentCode');
            const loginBtn = document.getElementById('loginBtn');

            const results = {
                form_exists: !!loginForm,
                student_input: !!studentInput,
                code_input: !!codeInput,
                login_button: !!loginBtn,
                correct_attributes: studentInput?.type === 'text' && 
                                  codeInput?.type === 'password' &&
                                  loginBtn?.type === 'submit'
            };

            this.addTestResult('نموذج تسجيل الدخول', results, Object.values(results).every(r => r));
        } catch (error) {
            this.addTestResult('نموذج تسجيل الدخول', { error: error.message }, false);
        }
    },

    // اختبار الأنماط CSS
    async testCSSStyles() {
        console.log('\n🎨 اختبار الأنماط CSS...');
        
        try {
            const requiredClasses = [
                'login-container',
                'login-card',
                'student-info-card',
                'stat-card',
                'followup-item',
                'comment-section',
                'page-header'
            ];

            const results = {};
            for (let className of requiredClasses) {
                const element = document.createElement('div');
                element.className = className;
                document.body.appendChild(element);
                
                const computed = window.getComputedStyle(element);
                const exists = computed.display !== 'none' || element.offsetWidth > 0;
                
                results[className] = exists;
                document.body.removeChild(element);
            }

            this.addTestResult('أنماط CSS', results, Object.values(results).every(r => r));
        } catch (error) {
            this.addTestResult('أنماط CSS', { error: error.message }, false);
        }
    },

    // اختبار وظائف JavaScript
    async testJavaScriptFunctions() {
        console.log('\n⚙️ اختبار وظائف JavaScript...');
        
        try {
            const requiredFunctions = [
                'ParentPortal',
                'escapeHtml',
                'formatDate',
                'formatDateTime',
                'getStatusClass',
                'getStatusColor'
            ];

            const results = {};
            for (let funcName of requiredFunctions) {
                let exists = false;
                
                if (funcName === 'ParentPortal') {
                    exists = typeof window[funcName] === 'function' || 
                            typeof window.parentPortal === 'object';
                } else {
                    exists = typeof window[funcName] === 'function';
                }
                
                results[funcName] = exists;
            }

            this.addTestResult('وظائف JavaScript', results, Object.values(results).every(r => r));
        } catch (error) {
            this.addTestResult('وظائف JavaScript', { error: error.message }, false);
        }
    },

    // اختبار التصميم المتجاوب
    async testResponsiveDesign() {
        console.log('\n📱 اختبار التصميم المتجاوب...');
        
        try {
            const viewportWidth = window.innerWidth;
            const hasMediaQueries = document.styleSheets.length > 0;
            
            let isMobile = viewportWidth < 768;
            let isTablet = viewportWidth >= 768 && viewportWidth < 1024;
            let isDesktop = viewportWidth >= 1024;

            const results = {
                mobile_viewport: isMobile,
                tablet_viewport: isTablet,
                desktop_viewport: isDesktop,
                has_stylesheets: hasMediaQueries,
                responsive_meta: document.querySelector('meta[name="viewport"]') !== null
            };

            this.addTestResult('التصميم المتجاوب', results, true);
        } catch (error) {
            this.addTestResult('التصميم المتجاوب', { error: error.message }, false);
        }
    },

    // اختبار إمكانية الوصول
    async testAccessibility() {
        console.log('\n♿ اختبار إمكانية الوصول...');
        
        try {
            const results = {
                has_lang_attribute: document.documentElement.lang === 'ar',
                has_dir_attribute: document.documentElement.dir === 'rtl',
                has_title: !!document.title,
                form_labels: document.querySelectorAll('label[for]').length > 0,
                alt_attributes: true // سيتم فحصها في العناصر التي تحتوي على صور
            };

            // فحص alt attributes للصور
            const images = document.querySelectorAll('img');
            if (images.length > 0) {
                results.alt_attributes = Array.from(images).every(img => 
                    img.alt !== undefined && img.alt !== null
                );
            }

            this.addTestResult('إمكانية الوصول', results, Object.values(results).every(r => r));
        } catch (error) {
            this.addTestResult('إمكانية الوصول', { error: error.message }, false);
        }
    },

    // اختبار الأداء
    async testPerformance() {
        console.log('\n⚡ اختبار الأداء...');
        
        try {
            const startTime = performance.now();
            
            // محاكاة تحميل البيانات
            await new Promise(resolve => setTimeout(resolve, 100));
            
            const endTime = performance.now();
            const loadTime = endTime - startTime;

            const results = {
                load_time: loadTime.toFixed(2) + 'ms',
                page_size_estimate: document.documentElement.outerHTML.length,
                css_files: document.querySelectorAll('link[rel="stylesheet"]').length,
                js_files: document.querySelectorAll('script[src]').length,
                performance_acceptable: loadTime < 1000
            };

            this.addTestResult('الأداء', results, results.performance_acceptable);
        } catch (error) {
            this.addTestResult('الأداء', { error: error.message }, false);
        }
    },

    // إضافة نتيجة اختبار
    addTestResult(testName, results, passed) {
        this.currentTest++;
        this.testResults.push({
            name: testName,
            results: results,
            passed: passed,
            timestamp: new Date().toISOString()
        });

        const status = passed ? '✅ نجح' : '❌ فشل';
        console.log(`${status} ${testName}`);
        
        if (!passed) {
            console.log('التفاصيل:', results);
        }
    },

    // عرض نتائج الاختبارات
    showTestResults() {
        console.log('\n📊 نتائج الاختبارات');
        console.log('=====================================');
        
        const totalTests = this.testResults.length;
        const passedTests = this.testResults.filter(t => t.passed).length;
        const failedTests = totalTests - passedTests;
        
        console.log(`إجمالي الاختبارات: ${totalTests}`);
        console.log(`نجحت: ${passedTests}`);
        console.log(`فشلت: ${failedTests}`);
        console.log(`معدل النجاح: ${((passedTests / totalTests) * 100).toFixed(1)}%`);

        if (failedTests > 0) {
            console.log('\n❌ الاختبارات الفاشلة:');
            this.testResults.filter(t => !t.passed).forEach(test => {
                console.log(`- ${test.name}`);
            });
        }

        // إنشاء تقرير HTML
        this.generateTestReport();
    },

    // إنشاء تقرير HTML
    generateTestReport() {
        const reportHTML = `
            <!DOCTYPE html>
            <html lang="ar" dir="rtl">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>تقرير اختبار بوابة ولي الأمر</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; direction: rtl; }
                    .header { background: #f0f8ff; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
                    .test-result { border: 1px solid #ddd; margin: 10px 0; padding: 15px; border-radius: 5px; }
                    .passed { background: #d4edda; border-color: #c3e6cb; }
                    .failed { background: #f8d7da; border-color: #f5c6cb; }
                    .summary { background: #e2e3e5; padding: 15px; border-radius: 5px; margin: 20px 0; }
                    .details { background: #f8f9fa; padding: 10px; border-radius: 3px; margin-top: 10px; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>📊 تقرير اختبار بوابة ولي الأمر</h1>
                    <p>تاريخ الاختبار: ${new Date().toLocaleString('ar-SA')}</p>
                    <p>URL: ${window.location.href}</p>
                </div>
                
                <div class="summary">
                    <h2>📈 الملخص العام</h2>
                    <p><strong>إجمالي الاختبارات:</strong> ${this.testResults.length}</p>
                    <p><strong>نجحت:</strong> ${this.testResults.filter(t => t.passed).length}</p>
                    <p><strong>فشلت:</strong> ${this.testResults.filter(t => !t.passed).length}</p>
                    <p><strong>معدل النجاح:</strong> ${((this.testResults.filter(t => t.passed).length / this.testResults.length) * 100).toFixed(1)}%</p>
                </div>
                
                <h2>📋 تفاصيل الاختبارات</h2>
                ${this.testResults.map(test => `
                    <div class="test-result ${test.passed ? 'passed' : 'failed'}">
                        <h3>${test.passed ? '✅' : '❌'} ${test.name}</h3>
                        <div class="details">
                            <pre>${JSON.stringify(test.results, null, 2)}</pre>
                        </div>
                        <p><em>وقت الاختبار: ${new Date(test.timestamp).toLocaleString('ar-SA')}</em></p>
                    </div>
                `).join('')}
            </body>
            </html>
        `;

        // فتح التقرير في نافذة جديدة
        const newWindow = window.open();
        newWindow.document.write(reportHTML);
        newWindow.document.close();
    }
};

// تشغيل الاختبارات عند تحميل الصفحة
if (typeof window !== 'undefined') {
    window.ParentPortalTest = ParentPortalTest;
    
    // إضافة زر اختبار في الواجهة
    document.addEventListener('DOMContentLoaded', function() {
        // إنشاء زر اختبار في التنقل
        const navbar = document.querySelector('.navbar-nav');
        if (navbar) {
            const testBtn = document.createElement('button');
            testBtn.textContent = '🧪 اختبار';
            testBtn.className = 'btn btn-outline btn-sm';
            testBtn.style.marginRight = '10px';
            testBtn.onclick = () => ParentPortalTest.runAllTests();
            navbar.insertBefore(testBtn, navbar.firstChild);
        }
        
        console.log('تم تحميل نظام اختبار بوابة ولي الأمر');
        console.log('للبدء، اكتب: ParentPortalTest.runAllTests()');
    });
}