/**
 * ملف JavaScript الرئيسي لبوابة ولي الأمر
 * نظام المتابعة الصفية الذكي
 */

// إعدادات عامة
const ParentPortalConfig = {
    API_BASE: window.location.origin,
    AUTO_REFRESH_INTERVAL: 30000, // 30 ثانية
    ALERT_DISPLAY_TIME: 5000, // 5 ثواني
    STORAGE_KEYS: {
        STUDENT_NUMBER: 'parentStudentNumber',
        STUDENT_NAME: 'parentStudentName',
        CLASS_NAME: 'parentClassName',
        LAST_SEEN: 'parentLastSeen',
        REMEMBER_ME: 'parentRememberMe'
    }
};

// متغيرات عامة
let currentStudent = null;
let currentStudentNumber = null;
let refreshTimer = null;
let isLoading = false;

// الكلاس الرئيسي لبوابة ولي الأمر
class ParentPortal {
    constructor() {
        this.initialize();
    }

    // تهيئة النظام
    initialize() {
        this.setupEventListeners();
        this.checkLoginStatus();
        this.setupAutoRefresh();
        this.addNotificationListener();
    }

    // إعداد مستمعي الأحداث
    setupEventListeners() {
        // نموذج تسجيل الدخول
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // نموذج إضافة تعليق
        const commentForm = document.getElementById('commentForm');
        if (commentForm) {
            commentForm.addEventListener('submit', (e) => this.handleCommentSubmit(e));
        }

        // تحديث البيانات
        const refreshBtn = document.getElementById('refreshBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => this.refreshData());
        }

        // تصغير النافذة تلقائياً عند عدم النشاط
        this.setupAutoHide();
    }

    // التحقق من حالة تسجيل الدخول
    checkLoginStatus() {
        const savedStudentNumber = localStorage.getItem(ParentPortalConfig.STORAGE_KEYS.STUDENT_NUMBER);
        if (savedStudentNumber) {
            currentStudentNumber = savedStudentNumber;
            this.showMainSection();
            this.loadStudentData();
        }
    }

    // تسجيل الدخول
    async handleLogin(event) {
        event.preventDefault();
        
        const loginBtn = document.getElementById('loginBtn');
        const studentNumber = document.getElementById('studentNumber').value.trim();
        const parentCode = document.getElementById('parentCode').value.trim();

        if (!studentNumber || !parentCode) {
            this.showAlert('error', 'يرجى إدخال رقم الطالب والرمز السري');
            return;
        }

        if (parentCode.length !== 10) {
            this.showAlert('error', 'الرمز السري يجب أن يكون 10 أحرف');
            return;
        }

        try {
            this.setLoadingState(loginBtn, true, '⏳ جاري التحقق...');

            const response = await this.makeApiRequest('/api/parent/verify-code', {
                method: 'POST',
                body: JSON.stringify({ parentCode })
            });

            if (response.success && response.studentNumber === studentNumber) {
                currentStudent = response;
                currentStudentNumber = studentNumber;

                // حفظ حالة تسجيل الدخول
                this.saveLoginState(response, studentNumber);

                this.showMainSection();
                await this.loadStudentData();
                this.showAlert('success', 'تم تسجيل الدخول بنجاح');
            } else {
                throw new Error(response.error || 'رقم الطالب أو الرمز السري غير صحيح');
            }
        } catch (error) {
            this.showAlert('error', error.message);
        } finally {
            this.setLoadingState(loginBtn, false, '🔐 تسجيل الدخول');
        }
    }

    // حفظ حالة تسجيل الدخول
    saveLoginState(studentData, studentNumber) {
        localStorage.setItem(ParentPortalConfig.STORAGE_KEYS.STUDENT_NUMBER, studentNumber);
        localStorage.setItem(ParentPortalConfig.STORAGE_KEYS.STUDENT_NAME, studentData.studentName);
        localStorage.setItem(ParentPortalConfig.STORAGE_KEYS.CLASS_NAME, studentData.className);
        localStorage.setItem(ParentPortalConfig.STORAGE_KEYS.LAST_SEEN, new Date().toISOString());
    }

    // عرض القسم الرئيسي
    showMainSection() {
        const loginSection = document.getElementById('loginSection');
        const mainSection = document.getElementById('mainSection');

        if (loginSection) loginSection.style.display = 'none';
        if (mainSection) mainSection.style.display = 'block';

        this.updateStudentInfo();
    }

    // تحديث معلومات الطالب
    updateStudentInfo() {
        if (currentStudent) {
            this.updateElementText('studentInfo', 
                `مرحباً بكم في متابعة أداء الطالب: ${this.escapeHtml(currentStudent.studentName)}`
            );
            this.updateElementText('studentName', currentStudent.studentName);
            this.updateElementText('studentNumberDisplay', currentStudent.studentNumber);
            this.updateElementText('classNameDisplay', currentStudent.className);
        } else {
            // محاولة استعادة البيانات من localStorage
            const savedName = localStorage.getItem(ParentPortalConfig.STORAGE_KEYS.STUDENT_NAME);
            const savedClass = localStorage.getItem(ParentPortalConfig.STORAGE_KEYS.CLASS_NAME);

            this.updateElementText('studentInfo', 'مرحباً بكم في متابعة أداء الطالب');
            this.updateElementText('studentName', savedName || 'غير محدد');
            this.updateElementText('studentNumberDisplay', currentStudentNumber || 'غير محدد');
            this.updateElementText('classNameDisplay', savedClass || 'غير محدد');
        }
    }

    // تحميل بيانات الطالب
    async loadStudentData() {
        if (!currentStudentNumber || isLoading) return;

        try {
            isLoading = true;
            await Promise.all([
                this.loadFollowups(),
                this.loadComments(),
                this.updateLastSeen()
            ]);
        } catch (error) {
            console.error('خطأ في تحميل البيانات:', error);
            this.showAlert('error', 'حدث خطأ أثناء تحميل البيانات');
        } finally {
            isLoading = false;
        }
    }

    // تحميل المتابعات
    async loadFollowups() {
        try {
            const followups = await this.makeApiRequest(`/api/parent/student-followups/${currentStudentNumber}`);
            
            if (Array.isArray(followups)) {
                this.displayFollowups(followups);
                this.updateStatistics(followups);
            } else {
                throw new Error(followups.error || 'فشل في تحميل المتابعات');
            }
        } catch (error) {
            this.showFollowupsError(error.message);
        }
    }

    // عرض المتابعات
    displayFollowups(followups) {
        const container = document.getElementById('followupsList');
        if (!container) return;

        if (followups.length === 0) {
            container.innerHTML = this.getEmptyStateHtml('📭 لا توجد متابعات مسجلة', 'سيتم عرض متابعات الأداء هنا عند توفرها');
            return;
        }

        const followupsHtml = followups.map(followup => this.createFollowupHtml(followup)).join('');
        container.innerHTML = followupsHtml;
    }

    // إنشاء HTML للمتابعة
    createFollowupHtml(followup) {
        const participationClass = this.getStatusClass(followup.participation_all);
        const homeworkClass = this.getStatusClass(followup.homework_all);
        
        return `
            <div class="followup-item" data-id="${followup.id}">
                <div class="row" style="align-items: center; margin-bottom: 16px;">
                    <div class="col-6">
                        <h3 style="margin: 0; color: var(--primary-700);">${this.escapeHtml(followup.subject)}</h3>
                        <p style="margin: 0; color: var(--text-secondary); font-size: 14px;">
                            👩‍🏫 ${this.escapeHtml(followup.teacher_name)}
                        </p>
                    </div>
                    <div class="col-6 text-left">
                        <p style="margin: 0; color: var(--text-secondary);">
                            📅 ${this.formatDate(followup.date)}
                        </p>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-6">
                        <p style="margin-bottom: 8px;">
                            <strong>المشاركة:</strong> 
                            <span style="color: ${this.getStatusColor(participationClass)};">
                                ${this.escapeHtml(followup.participation_all)} 
                                <span class="status-indicator ${participationClass}"></span>
                            </span>
                        </p>
                    </div>
                    <div class="col-6">
                        <p style="margin-bottom: 8px;">
                            <strong>الواجبات:</strong> 
                            <span style="color: ${this.getStatusColor(homeworkClass)};">
                                ${this.escapeHtml(followup.homework_all)} 
                                <span class="status-indicator ${homeworkClass}"></span>
                            </span>
                        </p>
                    </div>
                </div>
                
                ${followup.notes ? `
                    <div style="margin-top: 16px; padding: 16px; background: var(--bg-page); border-radius: 8px;">
                        <p style="margin: 0; font-weight: 500;">📝 الملاحظات:</p>
                        <p style="margin: 8px 0 0 0;">${this.escapeHtml(followup.notes)}</p>
                    </div>
                ` : ''}
            </div>
        `;
    }

    // تحديث الإحصائيات
    updateStatistics(followups) {
        const totalFollowups = followups.length;
        const excellentDays = followups.filter(f => 
            (f.participation_all === 'ممتاز' || f.participation_all === 'جيد جداً') &&
            (f.homework_all === 'ممتاز' || f.homework_all === 'جيد جداً')
        ).length;

        const homeworkCompleted = followups.filter(f => 
            f.homework_all === 'ممتاز' || f.homework_all === 'جيد جداً' || f.homework_all === 'جيد'
        ).length;

        const participationRate = totalFollowups > 0 ? 
            Math.round((followups.filter(f => 
                f.participation_all === 'ممتاز' || f.participation_all === 'جيد جداً' || f.participation_all === 'جيد'
            ).length / totalFollowups) * 100) : 0;

        this.updateElementText('totalFollowups', totalFollowups);
        this.updateElementText('excellentDays', excellentDays);
        this.updateElementText('homeworkCompleted', homeworkCompleted);
        this.updateElementText('participationRate', participationRate + '%');
    }

    // عرض خطأ في المتابعات
    showFollowupsError(errorMessage) {
        const container = document.getElementById('followupsList');
        if (container) {
            container.innerHTML = this.getEmptyStateHtml('❌ خطأ في تحميل البيانات', errorMessage, true);
        }
    }

    // تحميل التعليقات
    async loadComments() {
        try {
            const comments = await this.makeApiRequest(`/api/parent/comments/${currentStudentNumber}`);
            
            if (Array.isArray(comments)) {
                this.displayComments(comments);
            } else {
                throw new Error(comments.error || 'فشل في تحميل التعليقات');
            }
        } catch (error) {
            this.showAlert('error', error.message);
        }
    }

    // عرض التعليقات
    displayComments(comments) {
        const container = document.getElementById('commentsList');
        if (!container) return;

        if (comments.length === 0) {
            container.innerHTML = this.getEmptyStateHtml('لا توجد تعليقات سابقة', '', false);
            return;
        }

        const commentsHtml = comments.map(comment => `
            <div class="comment-item" data-id="${comment.id}">
                <div class="comment-date">
                    📅 ${this.formatDateTime(comment.created_at)}
                </div>
                <p style="margin: 0;">${this.escapeHtml(comment.comment_text)}</p>
            </div>
        `).join('');

        container.innerHTML = commentsHtml;
    }

    // إرسال تعليق
    async handleCommentSubmit(event) {
        event.preventDefault();

        const commentBtn = document.getElementById('commentBtn');
        const commentText = document.getElementById('commentText').value.trim();

        if (!commentText) {
            this.showAlert('error', 'يرجى كتابة تعليق');
            return;
        }

        try {
            this.setLoadingState(commentBtn, true, '⏳ جاري الإرسال...');

            const response = await this.makeApiRequest('/api/parent/comments', {
                method: 'POST',
                body: JSON.stringify({
                    studentNumber: currentStudentNumber,
                    commentText: commentText
                })
            });

            if (response.message) {
                this.showAlert('success', response.message);
                this.clearElement('commentForm');
                await this.loadComments();
            } else {
                throw new Error(response.error || 'فشل في إرسال التعليق');
            }
        } catch (error) {
            this.showAlert('error', error.message);
        } finally {
            this.setLoadingState(commentBtn, false, '💬 إرسال التعليق');
        }
    }

    // تحديث آخر مشاهدة
    updateLastSeen() {
        localStorage.setItem(ParentPortalConfig.STORAGE_KEYS.LAST_SEEN, new Date().toISOString());
        this.updateElementText('lastUpdateDisplay', this.formatDateTime(new Date().toISOString()));
    }

    // تحديث البيانات
    async refreshData() {
        if (isLoading) return;
        
        this.showAlert('info', 'جاري تحديث البيانات...');
        await this.loadStudentData();
        this.showAlert('success', 'تم تحديث البيانات بنجاح');
    }

    // إعداد التحديث التلقائي
    setupAutoRefresh() {
        if (refreshTimer) {
            clearInterval(refreshTimer);
        }

        refreshTimer = setInterval(() => {
            if (currentStudentNumber && !isLoading) {
                this.loadStudentData();
            }
        }, ParentPortalConfig.AUTO_REFRESH_INTERVAL);
    }

    // إعداد إخفاء تلقائي للنوافذ
    setupAutoHide() {
        let hideTimer = null;
        const resetHideTimer = () => {
            if (hideTimer) clearTimeout(hideTimer);
            hideTimer = setTimeout(() => {
                // يمكن إضافة منطق إخفاء النوافذ المنبثقة هنا
            }, 30000); // 30 ثانية
        };

        document.addEventListener('mousemove', resetHideTimer);
        document.addEventListener('keydown', resetHideTimer);
    }

    // إضافة مستمع الإشعارات
    addNotificationListener() {
        if ('Notification' in window && Notification.permission === 'default') {
            Notification.requestPermission();
        }
    }

    // تسجيل الخروج
    logout() {
        if (confirm('هل أنت متأكد من تسجيل الخروج؟')) {
            this.clearLoginState();
            location.reload();
        }
    }

    // مسح حالة تسجيل الدخول
    clearLoginState() {
        Object.values(ParentPortalConfig.STORAGE_KEYS).forEach(key => {
            localStorage.removeItem(key);
        });
        
        currentStudent = null;
        currentStudentNumber = null;
        
        if (refreshTimer) {
            clearInterval(refreshTimer);
        }
    }

    // وظائف مساعدة

    // إجراء طلب API
    async makeApiRequest(url, options = {}) {
        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
            },
        };

        const response = await fetch(ParentPortalConfig.API_BASE + url, {
            ...defaultOptions,
            ...options,
        });

        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || `HTTP ${response.status}`);
        }

        return data;
    }

    // تحديث حالة التحميل
    setLoadingState(element, isLoading, text) {
        if (element) {
            element.disabled = isLoading;
            element.innerHTML = text;
        }
    }

    // تحديث نص العنصر
    updateElementText(elementId, text) {
        const element = document.getElementById(elementId);
        if (element) {
            element.textContent = text;
        }
    }

    // مسح العنصر
    clearElement(elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            element.reset();
        }
    }

    // إنشاء HTML للحالة الفارغة
    getEmptyStateHtml(title, description, isError = false) {
        const icon = isError ? '❌' : '📭';
        const className = isError ? 'error' : 'empty';
        
        return `
            <div class="text-center" style="padding: 48px;">
                <h3 style="margin-bottom: 16px; color: ${isError ? 'var(--error)' : 'var(--text-secondary)'};">
                    ${icon} ${title}
                </h3>
                ${description ? `<p class="text-secondary">${this.escapeHtml(description)}</p>` : ''}
            </div>
        `;
    }

    // تحديد فئة الحالة
    getStatusClass(status) {
        if (!status) return '';

        const excellentKeywords = ['ممتاز', 'جيد جداً'];
        const goodKeywords = ['جيد'];
        const warningKeywords = ['متوسط', 'يحتاج تحسين'];
        const poorKeywords = ['ضعيف', 'سيء'];

        if (excellentKeywords.some(keyword => status.includes(keyword))) {
            return 'status-excellent';
        } else if (goodKeywords.some(keyword => status.includes(keyword))) {
            return 'status-good';
        } else if (warningKeywords.some(keyword => status.includes(keyword))) {
            return 'status-needs-improvement';
        } else if (poorKeywords.some(keyword => status.includes(keyword))) {
            return 'status-poor';
        }
        return 'status-good';
    }

    // تحديد لون الحالة
    getStatusColor(statusClass) {
        const colors = {
            'status-excellent': 'var(--success)',
            'status-good': '#17a2b8',
            'status-needs-improvement': 'var(--warning)',
            'status-poor': 'var(--error)'
        };
        return colors[statusClass] || 'var(--text-secondary)';
    }

    // تنسيق التاريخ
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('ar-SA', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }

    // تنسيق التاريخ والوقت
    formatDateTime(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('ar-SA', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // حماية من XSS
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // إظهار تنبيه
    showAlert(type, message) {
        const alertHtml = `
            <div class="alert alert-${type}" role="alert">
                ${this.escapeHtml(message)}
                <button type="button" class="close" onclick="this.parentElement.remove()">
                    <span>&times;</span>
                </button>
            </div>
        `;

        const container = document.getElementById('alerts');
        if (container) {
            container.innerHTML = alertHtml;

            setTimeout(() => {
                const alert = container.querySelector('.alert');
                if (alert) {
                    alert.style.opacity = '0';
                    setTimeout(() => alert.remove(), 300);
                }
            }, ParentPortalConfig.ALERT_DISPLAY_TIME);
        }

        // إظهار إشعار المتصفح إذا كان متاحاً
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('بوابة ولي الأمر', {
                body: message,
                icon: '/favicon.ico'
            });
        }
    }
}

// تهيئة النظام عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    // إنشاء نسخة من النظام
    window.parentPortal = new ParentPortal();

    // إضافة الوظائف إلى النطاق العام
    window.logout = () => window.parentPortal.logout();
    window.refreshData = () => window.parentPortal.refreshData();
    window.showAlert = (type, message) => window.parentPortal.showAlert(type, message);
    window.escapeHtml = (text) => window.parentPortal.escapeHtml(text);
});

// التعامل مع إعادة تحميل الصفحة
window.addEventListener('beforeunload', function() {
    // حفظ البيانات المهمة قبل إغلاق الصفحة
    if (currentStudentNumber) {
        localStorage.setItem(ParentPortalConfig.STORAGE_KEYS.LAST_SEEN, new Date().toISOString());
    }
});

// التعامل مع تغير حالة الاتصال
window.addEventListener('online', function() {
    if (window.parentPortal) {
        window.parentPortal.showAlert('success', 'تم استعادة الاتصال بالإنترنت');
        window.parentPortal.refreshData();
    }
});

window.addEventListener('offline', function() {
    if (window.parentPortal) {
        window.parentPortal.showAlert('warning', 'لا يوجد اتصال بالإنترنت');
    }
});