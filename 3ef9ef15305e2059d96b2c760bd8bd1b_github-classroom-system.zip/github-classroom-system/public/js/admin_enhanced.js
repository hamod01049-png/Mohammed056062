/**
 * نظام إدارة البيانات المتقدمة - JavaScript
 * Smart Classroom Monitoring System
 */

class AdminDataManager {
    constructor() {
        this.currentUser = null;
        this.permissions = null;
        this.refreshInterval = null;
        this.init();
    }

    async init() {
        try {
            await this.checkAuth();
            await this.loadUserPermissions();
            this.setupEventListeners();
            this.startAutoRefresh();
        } catch (error) {
            console.error('خطأ في تهيئة النظام:', error);
            this.showAlert('خطأ في تهيئة النظام', 'error');
        }
    }

    // التحقق من المصادقة
    async checkAuth() {
        try {
            const response = await fetch('/api/admin/check-auth');
            const data = await response.json();
            
            if (!data.authenticated) {
                window.location.href = '/admin-login';
                return false;
            }
            
            this.currentUser = data.user;
            return true;
        } catch (error) {
            console.error('خطأ في التحقق من المصادقة:', error);
            return false;
        }
    }

    // تحميل صلاحيات المستخدم
    async loadUserPermissions() {
        try {
            const response = await fetch('/api/admin/user-permissions');
            const data = await response.json();
            
            if (data.success) {
                this.permissions = data.permissions;
                this.applyPermissions();
            }
        } catch (error) {
            console.error('خطأ في تحميل الصلاحيات:', error);
        }
    }

    // تطبيق الصلاحيات على الواجهة
    applyPermissions() {
        if (!this.permissions) return;

        // إخفاء العناصر حسب الصلاحيات
        const elementsToHide = document.querySelectorAll('[data-permission]');
        elementsToHide.forEach(element => {
            const requiredPermission = element.getAttribute('data-permission');
            if (!this.permissions[requiredPermission]) {
                element.style.display = 'none';
            }
        });

        // تعطيل الأزرار حسب الصلاحيات
        const buttonsToDisable = document.querySelectorAll('[data-permission-required]');
        buttonsToDisable.forEach(button => {
            const requiredPermission = button.getAttribute('data-permission-required');
            if (!this.permissions[requiredPermission]) {
                button.disabled = true;
                button.title = 'ليس لديك صلاحية لتنفيذ هذه العملية';
            }
        });
    }

    // إعداد مستمعي الأحداث
    setupEventListeners() {
        // التبديل بين التبويبات
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.addEventListener('click', (e) => {
                this.switchTab(e.target.getAttribute('data-tab') || e.target.textContent.trim());
            });
        });

        // حفظ الإعدادات
        document.getElementById('saveSettings')?.addEventListener('click', () => {
            this.saveSystemSettings();
        });

        // حفظ إعدادات الإشعارات
        document.getElementById('saveNotificationSettings')?.addEventListener('click', () => {
            this.saveNotificationSettings();
        });

        // تحديث مؤشرات الأداء
        this.updatePerformanceIndicators();
    }

    // بدء التحديث التلقائي
    startAutoRefresh() {
        // تحديث مؤشرات الأداء كل 30 ثانية
        this.refreshInterval = setInterval(() => {
            this.updatePerformanceIndicators();
        }, 30000);

        // تحديث الإحصائيات كل دقيقة
        setInterval(() => {
            if (document.querySelector('.nav-tab.active')?.textContent.includes('نظرة عامة')) {
                this.loadOverviewStats();
            }
        }, 60000);
    }

    // إيقاف التحديث التلقائي
    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }

    // تبديل التبويبات
    switchTab(tabName) {
        // إخفاء جميع التبويبات
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.remove('active');
        });
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });

        // إظهار التبويب المحدد
        const targetTab = document.getElementById(tabName);
        const targetButton = Array.from(document.querySelectorAll('.nav-tab')).find(tab => 
            tab.textContent.includes(tabName) || tab.getAttribute('data-tab') === tabName
        );

        if (targetTab) {
            targetTab.classList.add('active');
        }
        if (targetButton) {
            targetButton.classList.add('active');
        }

        // تحميل البيانات حسب التبويب
        this.loadTabData(tabName);
    }

    // تحميل بيانات التبويب
    async loadTabData(tabName) {
        try {
            switch(tabName) {
                case 'overview':
                    await this.loadOverviewStats();
                    await this.loadDetailedStats();
                    break;
                case 'advanced-data':
                    await this.loadDatabaseInfo();
                    await this.loadTablesInfo();
                    break;
                case 'permissions':
                    await this.loadUsersList();
                    await this.loadSystemPermissions();
                    break;
                case 'monitoring':
                    await this.loadPerformanceMetrics();
                    await this.loadActivityLog();
                    break;
                case 'backup':
                    await this.loadBackupLogs();
                    break;
                case 'export':
                    await this.loadExportStats();
                    break;
            }
        } catch (error) {
            console.error(`خطأ في تحميل بيانات التبويب ${tabName}:`, error);
        }
    }

    // تحميل الإحصائيات العامة
    async loadOverviewStats() {
        try {
            this.showLoader('statsGrid');
            const response = await fetch('/api/admin/overview-stats');
            const data = await response.json();
            
            if (data.success) {
                this.updateStatsDisplay(data.stats);
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('خطأ في تحميل الإحصائيات:', error);
            this.showAlert('خطأ في تحميل الإحصائيات', 'error');
        } finally {
            this.hideLoader('statsGrid');
        }
    }

    // تحديث عرض الإحصائيات
    updateStatsDisplay(stats) {
        const elements = {
            'totalFollowups': stats.totalFollowups,
            'weekFollowups': stats.thisWeekFollowups,
            'monthFollowups': stats.thisMonthFollowups,
            'activeClasses': stats.totalClasses,
            'activeStudents': stats.activeStudents,
            'archivedRecords': stats.archivedRecords
        };

        Object.entries(elements).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                this.animateNumber(element, value);
            }
        });
    }

    // تحريك الأرقام
    animateNumber(element, targetValue) {
        const startValue = 0;
        const duration = 1000;
        const startTime = performance.now();

        const update = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const currentValue = Math.floor(progress * (targetValue - startValue) + startValue);
            
            element.textContent = currentValue.toLocaleString();
            
            if (progress < 1) {
                requestAnimationFrame(update);
            }
        };

        requestAnimationFrame(update);
    }

    // تحميل معلومات قاعدة البيانات
    async loadDatabaseInfo() {
        try {
            this.showLoader('databaseInfo');
            const response = await fetch('/api/admin/database-info');
            const data = await response.json();
            
            if (data.success) {
                this.renderDatabaseInfo(data.info);
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('خطأ في تحميل معلومات قاعدة البيانات:', error);
            this.showAlert('خطأ في تحميل معلومات قاعدة البيانات', 'error');
        } finally {
            this.hideLoader('databaseInfo');
        }
    }

    // عرض معلومات قاعدة البيانات
    renderDatabaseInfo(info) {
        const html = `
            <div class="info-panel">
                <h4>معلومات قاعدة البيانات</h4>
                <table class="advanced-table">
                    <tr>
                        <td><strong>نوع قاعدة البيانات</strong></td>
                        <td>${info.type}</td>
                        <td><span class="status-indicator status-active">سليم</span></td>
                    </tr>
                    <tr>
                        <td><strong>إصدار قاعدة البيانات</strong></td>
                        <td>${info.version}</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><strong>حجم قاعدة البيانات</strong></td>
                        <td>${info.size}</td>
                        <td><span class="status-indicator ${info.sizeMB > 1000 ? 'status-warning' : 'status-active'}">
                            ${info.sizeMB > 1000 ? 'يحتاج تحسين' : 'طبيعي'}
                        </span></td>
                    </tr>
                    <tr>
                        <td><strong>عدد الجداول</strong></td>
                        <td>${info.tables}</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><strong>عدد السجلات</strong></td>
                        <td>${info.totalRecords.toLocaleString()}</td>
                        <td></td>
                    </tr>
                    <tr>
                        <td><strong>آخر تحديث</strong></td>
                        <td>${info.lastUpdate}</td>
                        <td></td>
                    </tr>
                </table>
            </div>
        `;
        
        document.getElementById('databaseInfo').innerHTML = html;
    }

    // تحميل معلومات الجداول
    async loadTablesInfo() {
        try {
            this.showLoader('tablesInfo');
            const response = await fetch('/api/admin/tables-info');
            const data = await response.json();
            
            if (data.success) {
                this.renderTablesInfo(data.tables);
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('خطأ في تحميل معلومات الجداول:', error);
            this.showAlert('خطأ في تحميل معلومات الجداول', 'error');
        } finally {
            this.hideLoader('tablesInfo');
        }
    }

    // عرض معلومات الجداول
    renderTablesInfo(tables) {
        const html = `
            <div class="chart-container">
                <h4>إحصائيات الجداول</h4>
                <table class="advanced-table">
                    <thead>
                        <tr>
                            <th>اسم الجدول</th>
                            <th>عدد السجلات</th>
                            <th>حجم الجدول</th>
                            <th>الفهارس</th>
                            <th>الحالة</th>
                            <th>آخر وصول</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${tables.map(table => `
                            <tr>
                                <td><strong>${table.name}</strong></td>
                                <td>${table.records.toLocaleString()}</td>
                                <td>${table.size}</td>
                                <td>${table.indexes}</td>
                                <td><span class="status-indicator ${this.getStatusClass(table.status)}">${table.status}</span></td>
                                <td>${table.lastAccess}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
        
        document.getElementById('tablesInfo').innerHTML = html;
    }

    // تحديد لون الحالة
    getStatusClass(status) {
        const statusMap = {
            'healthy': 'status-active',
            'warning': 'status-warning',
            'error': 'status-error',
            'optimized': 'status-info'
        };
        return statusMap[status] || 'status-info';
    }

    // تحميل قائمة المستخدمين
    async loadUsersList() {
        try {
            this.showLoader('usersList');
            const response = await fetch('/api/admin/users-list');
            const data = await response.json();
            
            if (data.success) {
                this.renderUsersList(data.users);
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('خطأ في تحميل قائمة المستخدمين:', error);
            this.showAlert('خطأ في تحميل قائمة المستخدمين', 'error');
        } finally {
            this.hideLoader('usersList');
        }
    }

    // عرض قائمة المستخدمين
    renderUsersList(users) {
        const html = `
            <div class="advanced-table-container">
                <table class="advanced-table">
                    <thead>
                        <tr>
                            <th>اسم المستخدم</th>
                            <th>نوع المستخدم</th>
                            <th>البريد الإلكتروني</th>
                            <th>آخر دخول</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${users.map(user => `
                            <tr>
                                <td><strong>${user.username}</strong></td>
                                <td>${this.getRoleName(user.role)}</td>
                                <td>${user.email || 'غير محدد'}</td>
                                <td>${user.lastLogin || 'لم يسجل دخول'}</td>
                                <td>
                                    <span class="status-indicator ${user.status === 'active' ? 'status-active' : 'status-error'}">
                                        ${user.status === 'active' ? 'نشط' : 'معطل'}
                                    </span>
                                </td>
                                <td>
                                    <button class="advanced-btn warning" onclick="adminManager.editUser('${user.username}')">
                                        تعديل
                                    </button>
                                    <button class="advanced-btn danger" onclick="adminManager.deleteUser('${user.username}')">
                                        حذف
                                    </button>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
        
        document.getElementById('usersList').innerHTML = html;
    }

    // الحصول على اسم الدور
    getRoleName(role) {
        const roleNames = {
            'system_admin': 'مدير النظام',
            'system_supervisor': 'مشرف النظام',
            'admin_assistant': 'مساعد إداري',
            'teacher': 'معلم',
            'supervisor': 'مشرف'
        };
        return roleNames[role] || role;
    }

    // تحميل مؤشرات الأداء
    async loadPerformanceMetrics() {
        try {
            const response = await fetch('/api/admin/performance-metrics');
            const data = await response.json();
            
            if (data.success) {
                this.renderPerformanceMetrics(data.metrics);
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('خطأ في تحميل مؤشرات الأداء:', error);
        }
    }

    // عرض مؤشرات الأداء
    renderPerformanceMetrics(metrics) {
        document.getElementById('dbSize').textContent = metrics.dbSize;
        document.getElementById('queryCount').textContent = metrics.queryCount.toLocaleString();
        document.getElementById('responseTime').textContent = metrics.avgResponseTime;
        document.getElementById('overallPerformance').textContent = metrics.overallPerformance + '%';
        
        // تحديث أشرطة التقدم
        const memoryUsage = document.getElementById('memoryUsage');
        const connections = document.getElementById('activeConnections');
        
        if (memoryUsage) {
            memoryUsage.style.width = metrics.memoryUsage + '%';
            document.getElementById('memoryUsageText').textContent = 
                `${metrics.memoryUsage}% من الذاكرة المستخدمة`;
        }
        
        if (connections) {
            const connectionPercentage = Math.min((metrics.activeConnections / 100) * 100, 100);
            connections.style.width = connectionPercentage + '%';
            document.getElementById('connectionsText').textContent = 
                `${metrics.activeConnections} اتصال نشط`;
        }
    }

    // تحديث مؤشرات الأداء
    updatePerformanceIndicators() {
        this.loadPerformanceMetrics();
    }

    // حفظ إعدادات النظام
    async saveSystemSettings() {
        const settings = {
            sessionTimeout: parseInt(document.getElementById('sessionTimeout')?.value || 30),
            maxLoginAttempts: parseInt(document.getElementById('maxLoginAttempts')?.value || 3),
            enableEncryption: document.getElementById('enableEncryption')?.checked || false,
            backupFrequency: document.getElementById('backupFrequency')?.value || 'daily',
            retentionDays: parseInt(document.getElementById('retentionDays')?.value || 30),
            autoCleanup: document.getElementById('autoCleanup')?.checked || false
        };

        try {
            this.showLoader('settings');
            const response = await fetch('/api/admin/save-settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(settings)
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert('تم حفظ الإعدادات بنجاح!', 'success');
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('خطأ في حفظ الإعدادات:', error);
            this.showAlert('خطأ في حفظ الإعدادات: ' + error.message, 'error');
        } finally {
            this.hideLoader('settings');
        }
    }

    // حفظ إعدادات الإشعارات
    async saveNotificationSettings() {
        const notificationSettings = {
            notifyBackup: document.getElementById('notifyBackup')?.checked || false,
            notifyCleanup: document.getElementById('notifyCleanup')?.checked || false,
            notifyErrors: document.getElementById('notifyErrors')?.checked || false,
            notifyPerformance: document.getElementById('notifyPerformance')?.checked || false,
            notificationEmail: document.getElementById('notificationEmail')?.value || '',
            notificationPhone: document.getElementById('notificationPhone')?.value || ''
        };

        try {
            this.showLoader('notification-settings');
            const response = await fetch('/api/admin/save-notification-settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(notificationSettings)
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showAlert('تم حفظ إعدادات الإشعارات بنجاح!', 'success');
            } else {
                throw new Error(data.error);
            }
        } catch (error) {
            console.error('خطأ في حفظ إعدادات الإشعارات:', error);
            this.showAlert('خطأ في حفظ إعدادات الإشعارات: ' + error.message, 'error');
        } finally {
            this.hideLoader('notification-settings');
        }
    }

    // عرض التنبيهات
    showAlert(message, type = 'info') {
        const alertContainer = document.getElementById('alertContainer') || this.createAlertContainer();
        
        const alertElement = document.createElement('div');
        alertElement.className = `advanced-alert advanced-alert-${type}`;
        alertElement.innerHTML = `
            <strong>${this.getAlertTitle(type)}</strong> ${message}
            <button onclick="this.parentElement.remove()" style="float: left; background: none; border: none; font-size: 1.2em; cursor: pointer;">&times;</button>
        `;
        
        alertContainer.appendChild(alertElement);
        
        // إزالة التنبيه تلقائياً بعد 5 ثوان
        setTimeout(() => {
            if (alertElement.parentNode) {
                alertElement.remove();
            }
        }, 5000);
    }

    // إنشاء حاوي التنبيهات
    createAlertContainer() {
        const container = document.createElement('div');
        container.id = 'alertContainer';
        container.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            max-width: 400px;
        `;
        document.body.appendChild(container);
        return container;
    }

    // الحصول على عنوان التنبيه
    getAlertTitle(type) {
        const titles = {
            'success': '✅ نجح',
            'error': '❌ خطأ',
            'warning': '⚠️ تحذير',
            'info': 'ℹ️ معلومات'
        };
        return titles[type] || 'ℹ️';
    }

    // إظهار المحدد
    showLoader(elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            element.innerHTML = `
                <div class="loading-container">
                    <div class="loading-spinner"></div>
                    <div class="loading-text">جاري التحميل...</div>
                </div>
            `;
        }
    }

    // إخفاء المحدد
    hideLoader(elementId) {
        // سيتم إخفاء المحدد عند تحديث المحتوى
    }

    // تنظيف الموارد عند إلغاء تحميل الصفحة
    cleanup() {
        this.stopAutoRefresh();
    }
}

// إنشاء مثيل مدير النظام
let adminManager;

// تهيئة النظام عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    adminManager = new AdminDataManager();
});

// تنظيف الموارد عند إلغاء تحميل الصفحة
window.addEventListener('beforeunload', function() {
    if (adminManager) {
        adminManager.cleanup();
    }
});