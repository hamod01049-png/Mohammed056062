const express = require('express');
const cors = require('cors');
const path = require('path');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const { Pool } = require('pg');
require('dotenv').config();

const app = express();

// إعدادات الأمان
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false
}));

// ضغط الاستجابات
app.use(compression());

// إعدادات CORS
app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? ['https://classroom-management-system.onrender.com'] 
    : true,
  credentials: true
}));

// حدود معدل الطلبات
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 دقيقة
  max: 100, // حد أقصى 100 طلب لكل 15 دقيقة
  message: 'تم تجاوز الحد المسموح من الطلبات، حاول مرة أخرى لاحقاً'
});
app.use(limiter);

// معالجة البيانات
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// اتصال قاعدة البيانات
let db;
let isPostgreSQL = false;

if (process.env.DATABASE_URL) {
  try {
    db = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: { 
        rejectUnauthorized: false 
      }
    });
    isPostgreSQL = true;
    console.log('✅ متصل بقاعدة بيانات PostgreSQL');
  } catch (error) {
    console.log('⚠️ فشل الاتصال بـ PostgreSQL، سيتم استخدام SQLite محلياً');
    db = null;
    isPostgreSQL = false;
  }
}

// إنشاء جداول قاعدة البيانات
async function createTables() {
  try {
    const queries = [
      // جدول الفصول
      `CREATE TABLE IF NOT EXISTS classes (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        archived_at TIMESTAMP,
        deleted_by VARCHAR(255)
      )`,
      
      // جدول الطلاب
      `CREATE TABLE IF NOT EXISTS students (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        class_id INTEGER REFERENCES classes(id),
        student_number VARCHAR(50) UNIQUE,
        parent_email VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        archived_at TIMESTAMP,
        deleted_by VARCHAR(255)
      )`,
      
      // جدول المتابعات
      `CREATE TABLE IF NOT EXISTS followups (
        id SERIAL PRIMARY KEY,
        student_id INTEGER REFERENCES students(id),
        date DATE NOT NULL,
        attendance VARCHAR(50),
        behavior TEXT,
        performance TEXT,
        notes TEXT,
        teacher_name VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        archived_at TIMESTAMP,
        deleted_by VARCHAR(255)
      )`,
      
      // جدول أكواد أولياء الأمور
      `CREATE TABLE IF NOT EXISTS parent_codes (
        id SERIAL PRIMARY KEY,
        student_id INTEGER REFERENCES students(id),
        student_number VARCHAR(50),
        parent_code VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // جدول تعليقات أولياء الأمور
      `CREATE TABLE IF NOT EXISTS parent_comments (
        id SERIAL PRIMARY KEY,
        student_number VARCHAR(50),
        comment_text TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        created_by VARCHAR(255),
        deleted_by VARCHAR(255)
      )`,
      
      // جدول البيانات المؤرشفة
      `CREATE TABLE IF NOT EXISTS archived_data (
        id SERIAL PRIMARY KEY,
        table_name VARCHAR(255) NOT NULL,
        record_id INTEGER NOT NULL,
        data_json TEXT NOT NULL,
        archived_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        archived_by VARCHAR(255)
      )`,
      
      // جدول سياسات الاحتفاظ بالبيانات
      `CREATE TABLE IF NOT EXISTS data_retention_policies (
        id SERIAL PRIMARY KEY,
        table_name VARCHAR(255) NOT NULL,
        retention_days INTEGER DEFAULT 365,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // جدول سجلات النسخ الاحتياطية
      `CREATE TABLE IF NOT EXISTS backup_logs (
        id SERIAL PRIMARY KEY,
        backup_type VARCHAR(50) NOT NULL,
        file_path TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status VARCHAR(50) DEFAULT 'pending'
      )`
    ];

    // إنشاء الفهارس
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_students_class_id ON students(class_id)',
      'CREATE INDEX IF NOT EXISTS idx_followups_student_id ON followups(student_id)',
      'CREATE INDEX IF NOT EXISTS idx_followups_date ON followups(date)',
      'CREATE INDEX IF NOT EXISTS idx_followups_archived_at ON followups(archived_at)',
      'CREATE INDEX IF NOT EXISTS idx_classes_archived_at ON classes(archived_at)',
      'CREATE INDEX IF NOT EXISTS idx_students_archived_at ON students(archived_at)',
      'CREATE INDEX IF NOT EXISTS idx_parent_codes_student_id ON parent_codes(student_id)',
      'CREATE INDEX IF NOT EXISTS idx_parent_comments_student_number ON parent_comments(student_number)',
      'CREATE INDEX IF NOT EXISTS idx_archived_data_table_name ON archived_data(table_name)',
      'CREATE INDEX IF NOT EXISTS idx_backup_logs_created_at ON backup_logs(created_at)'
    ];

    for (const query of queries) {
      await db.query(query);
    }

    for (const index of indexes) {
      await db.query(index);
    }

    console.log('✅ تم إنشاء جميع الجداول والفهارس بنجاح');
  } catch (error) {
    console.error('❌ خطأ في إنشاء الجداول:', error);
    throw error;
  }
}

// نقاط النهاية الصحية
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    database: isPostgreSQL ? 'PostgreSQL' : 'SQLite',
    version: process.env.npm_package_version || '2.0.0'
  });
});

// نقطة نهاية الجذر
app.get('/', (req, res) => {
  res.json({
    message: 'نظام متابعة الفصول الدراسية الذكية',
    version: '2.0.0',
    status: 'تم النشر بنجاح على Render ✅',
    timestamp: new Date().toISOString()
  });
});

// API الفصول
app.get('/api/classes', async (req, res) => {
  try {
    const query = 'SELECT * FROM classes WHERE archived_at IS NULL ORDER BY created_at DESC';
    const result = await db.query(query);
    res.json(result.rows);
  } catch (error) {
    console.error('خطأ في جلب الفصول:', error);
    res.status(500).json({ error: 'فشل في جلب بيانات الفصول' });
  }
});

// API الطلاب
app.get('/api/students', async (req, res) => {
  try {
    const query = `
      SELECT s.*, c.name as class_name 
      FROM students s 
      LEFT JOIN classes c ON s.class_id = c.id 
      WHERE s.archived_at IS NULL 
      ORDER BY s.created_at DESC
    `;
    const result = await db.query(query);
    res.json(result.rows);
  } catch (error) {
    console.error('خطأ في جلب الطلاب:', error);
    res.status(500).json({ error: 'فشل في جلب بيانات الطلاب' });
  }
});

// API المتابعات
app.get('/api/followups', async (req, res) => {
  try {
    const { student_id, start_date, end_date, include_archived } = req.query;
    
    let query = `
      SELECT f.*, s.name as student_name, s.student_number, c.name as class_name
      FROM followups f
      LEFT JOIN students s ON f.student_id = s.id
      LEFT JOIN classes c ON s.class_id = c.id
      WHERE 1=1
    `;
    
    const params = [];
    let paramCount = 1;
    
    if (student_id) {
      query += ` AND f.student_id = $${paramCount}`;
      params.push(student_id);
      paramCount++;
    }
    
    if (start_date) {
      query += ` AND f.date >= $${paramCount}`;
      params.push(start_date);
      paramCount++;
    }
    
    if (end_date) {
      query += ` AND f.date <= $${paramCount}`;
      params.push(end_date);
      paramCount++;
    }
    
    if (include_archived !== 'true') {
      query += ` AND f.archived_at IS NULL`;
    }
    
    query += ` ORDER BY f.date DESC, f.created_at DESC`;
    
    const result = await db.query(query, params);
    res.json(result.rows);
  } catch (error) {
    console.error('خطأ في جلب المتابعات:', error);
    res.status(500).json({ error: 'فشل في جلب بيانات المتابعات' });
  }
});

// API الإحصائيات
app.get('/api/stats', async (req, res) => {
  try {
    const queries = {
      total_classes: 'SELECT COUNT(*) as count FROM classes WHERE archived_at IS NULL',
      total_students: 'SELECT COUNT(*) as count FROM students WHERE archived_at IS NULL',
      total_followups: 'SELECT COUNT(*) as count FROM followups WHERE archived_at IS NULL',
      recent_followups: 'SELECT COUNT(*) as count FROM followups WHERE archived_at IS NULL AND date >= CURRENT_DATE - INTERVAL \'7 days\'',
      active_teachers: 'SELECT COUNT(DISTINCT teacher_name) as count FROM followups WHERE archived_at IS NULL AND teacher_name IS NOT NULL'
    };
    
    const stats = {};
    
    for (const [key, query] of Object.entries(queries)) {
      const result = await db.query(query);
      stats[key] = parseInt(result.rows[0].count);
    }
    
    res.json(stats);
  } catch (error) {
    console.error('خطأ في جلب الإحصائيات:', error);
    res.status(500).json({ error: 'فشل في جلب الإحصائيات' });
  }
});

// معالجة الأخطاء العامة
app.use((error, req, res, next) => {
  console.error('خطأ في الخادم:', error);
  res.status(500).json({
    error: 'خطأ في الخادم',
    message: process.env.NODE_ENV === 'production' 
      ? 'حدث خطأ في الخادم' 
      : error.message
  });
});

// صفحة 404
app.use((req, res) => {
  res.status(404).json({ error: 'الصفحة غير موجودة' });
});

// بدء الخادم
const PORT = process.env.PORT || 10000;

async function startServer() {
  try {
    if (db) {
      await createTables();
    }
    
    app.listen(PORT, () => {
      console.log(`
🚀 تم تشغيل الخادم بنجاح على المنفذ ${PORT}
📊 قاعدة البيانات: ${isPostgreSQL ? 'PostgreSQL' : 'SQLite'}
🌐 الرابط: https://classroom-management-system.onrender.com
⏰ الوقت: ${new Date().toLocaleString('ar-SA')}
✅ النظام جاهز للاستخدام!
      `);
    });
  } catch (error) {
    console.error('❌ فشل في بدء الخادم:', error);
    process.exit(1);
  }
}

// معالجة إغلاق العملية بأمان
process.on('SIGTERM', () => {
  console.log('🛑 تم استلام إشارة SIGTERM، إغلاق الخادم...');
  if (db) {
    db.end();
  }
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('🛑 تم استلام إشارة SIGINT، إغلاق الخادم...');
  if (db) {
    db.end();
  }
  process.exit(0);
});

startServer();